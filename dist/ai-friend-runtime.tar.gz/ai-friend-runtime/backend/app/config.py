from pathlib import Path

from pydantic import Field, computed_field, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

_env_file = Path(__file__).resolve().parent.parent.parent / ".env"


class AppSettings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=str(_env_file), env_file_encoding="utf-8", extra="ignore"
    )

    DEBUG: bool = False
    # #162: the one signal `validate_no_placeholder_secrets_in_production`
    # gates on. Deliberately not derived from `DEBUG` (which defaults False in
    # every CI run and most local dev sessions too, so gating on it would fire
    # the placeholder check constantly where it shouldn't) or from `DATABASE_
    # URL`'s shape (which says nothing about whether this deployment is meant
    # to be reachable by anyone but its operator). Unset -- the default --
    # means the check never runs, so nothing about existing behavior changes
    # until an operator explicitly opts in.
    ENVIRONMENT: str = "development"
    # #160: `main.py` already reads this via `getattr(Config, "LOG_JSON",
    # False)` to pick JSON vs plain-text logging, but the field was never
    # actually declared here - `extra="ignore"` meant setting LOG_JSON=true
    # in .env had silently no effect at all, always falling through to the
    # getattr default. The JSON formatter itself (logging_config.py) was
    # already correct; only the toggle to reach it was dead.
    LOG_JSON: bool = False
    TESTING_CONSOLIDATION_BYPASS_SILENCE: bool = False
    ALLOWED_ORIGINS_STR: str = Field(default="*", alias="ALLOWED_ORIGINS")
    LAN_ONLY: bool = True
    BACKEND_ACCESS_KEY: str | None = None
    # C4: unchanged default (0.0.0.0) so nothing breaks today -- Docker
    # deployments need this regardless of LAN_ONLY, since Docker's port
    # publishing forwards to the container's network interface, not loopback.
    # This exists for the bare `python main.py` / no-Docker path, where an
    # operator who wants to restrict exposure (e.g. behind their own reverse
    # proxy) now has a lever instead of needing a code change.
    BACKEND_BIND_HOST: str = "0.0.0.0"  # nosec B104 - see the C4 comment above
    # H3: caps how many session tokens one client IP can mint per window.
    # BACKEND_ACCESS_KEY already gates *who* can call /token; this bounds how
    # often, since a valid key doesn't imply unlimited LiveKit room creation.
    TOKEN_RATE_LIMIT_MAX_REQUESTS: int = 5
    TOKEN_RATE_LIMIT_WINDOW_SECONDS: float = 60.0
    LAN_CORS_ORIGIN_REGEX: str = (
        r"^https?://("
        r"127\.0\.0\.1|"
        r"127(?:\.\d{1,3}){3}|"
        r"10(?:\.\d{1,3}){3}|"
        r"192\.168(?:\.\d{1,3}){2}|"
        r"172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2}"
        r")(?::\d+)?$"
    )

    # NATS Configuration
    NATS_URL: str = "nats://127.0.0.1:4222"

    # Redis Configuration
    REDIS_URL: str = "redis://127.0.0.1:6379"

    # Qdrant Configuration
    QDRANT_HOST: str = "127.0.0.1"
    QDRANT_PORT: int = 6333

    # LiveKit Configuration
    LIVEKIT_URL: str = "ws://127.0.0.1:7880"
    # Browser-facing URL. In Compose this differs from LIVEKIT_URL, which is
    # resolvable only by services on the internal Docker network.
    LIVEKIT_PUBLIC_URL: str = "ws://127.0.0.1:7880"
    LIVEKIT_API_KEY: str | None = None
    LIVEKIT_API_SECRET: str | None = None

    # Memory & Personality
    DATABASE_URL: str | None = None
    PERSONALITY_SEED_PATH: str | None = None
    HISTORY_SEED_PATH: str | None = None
    # A user-authored persona (see app/persona/profile.py). Unset means "use the
    # PSYCH_* / AI_NAME defaults below", which is exactly the previous behaviour.
    PERSONA_PROFILE_PATH: str | None = None
    # The authored biography (see app/persona/biography.py). Unset means "walk
    # up for config/biography.md", the historical behaviour. Set, it can point
    # anywhere — which is the point: a biography is a real person's life, and
    # keeping it out of the repo should not require a code change.
    BIOGRAPHY_PATH: str | None = None
    # Where `IdentityManager` writes runtime `personality.json`/`history.json`
    # evolution. Unset means a `.identity_state/` directory beside (not inside)
    # the `app/` package — outside the git-tracked tree, unlike the historical
    # default of "beside the code", which made the package directory itself
    # writable state and let a save without a durable store dirty a tracked
    # file (see H2 / issue #113). Containers should point this at a mounted
    # volume, e.g. `/app/data`.
    IDENTITY_BASE_PATH: str | None = None
    # Whether a fresh write location with no existing personality.json/
    # history.json gets seeded from the shipped `PERSONALITY_SEED_PATH`/
    # `HISTORY_SEED_PATH` (or package-directory defaults) on first use. True in
    # every real deployment, so a fresh install still boots with the shipped
    # persona instead of an empty one now that the write default no longer
    # matches the seed location. The test suite disables this (like it already
    # disables `PERSONA_PROFILE_PATH` discovery) so a fresh per-session temp
    # directory stays genuinely empty rather than picking up the repo's seed.
    IDENTITY_SEED_ON_FIRST_BOOT: bool = True

    # Neo4j Graph Configuration
    NEO4J_URI: str | None = None
    NEO4J_USER: str = "neo4j"
    NEO4J_PASSWORD: str | None = None
    NEO4J_AUTH: str | None = None

    AI_NAME: str = "AI Friend"
    OLLAMA_URL: str = "http://127.0.0.1:11434"

    # Roadmap Phase 4.2: bring-your-own cloud API key for hardware that can't
    # host a local model. "ollama" (the default) is every construction site's
    # existing behaviour, unchanged. Sends conversation to a third party --
    # the opposite of this project's default local-first posture -- so it is
    # never the default and the user must set it explicitly.
    LLM_PROVIDER: str = "ollama"
    ANTHROPIC_API_KEY: str | None = None

    LLM_FAST_MODEL: str = "llama3.2:3b"
    LLM_CHAT_MODEL: str | None = None
    LLM_REFLECTION_MODEL: str | None = None

    LLM_STREAM_MAX_SECONDS: int = 120
    LLM_INTENT_CLASSIFICATION_ENABLED: bool = True

    # P1-1: the control tier's JetStream consumer settings (system.tick).
    # Both were previously implicit -- a 30s server-default ack_wait and
    # UNLIMITED max_deliver -- while the tick callback ran a ~28s
    # consolidation inline before ack. That combination is what produced
    # duplicate consolidations and duplicate proactive utterances: the
    # callback outran the deadline and JetStream redelivered, forever.
    #
    # With consolidation dispatched to a worker, the callback's remaining
    # worst case is one short proactive-thought LLM call, so this deadline
    # is now a genuine liveness bound rather than a number chosen to
    # accommodate a defect -- which is exactly why the roadmap requires
    # P1-1 to land before P1-2 sizes the control tier.
    MESH_CONTROL_ACK_WAIT_S: float = 30.0
    # Bounded, unlike the JetStream default. A tick that fails repeatedly is
    # a bug to surface, not a message to retry forever.
    MESH_CONTROL_MAX_DELIVER: int = 3
    MOCK_LLM_TEXT: bool = False

    # Stage 3 (audit/ROADMAP.md §7): off by default. When true, transport_agent,
    # subconscious_agent, and ollama_client emit the timestamps and prompt
    # digests backend/tools/measure/ needs for measurements 1.1, 1.2 and 1.5.
    # A prompt digest is recorded unconditionally when this is on; the full
    # prompt text is not, so turning this on in a real deployment does not by
    # itself start logging conversation content.
    MEASURE_TRACE: bool = False
    # Separate from MEASURE_TRACE on purpose: the digest above is safe to log
    # unconditionally, but measurement 1.5 (prompt-prefix sharing) needs the
    # literal prompt text to compute a shared prefix across a turn's six LLM
    # calls -- a hash can't do that. This second flag is what actually opts a
    # run into logging conversation content, and stays off even when
    # MEASURE_TRACE is on.
    MEASURE_TRACE_FULL_PROMPTS: bool = False

    REFLECTION_ENABLED: bool = True
    REFLECTION_MIN_INTERVAL_SECONDS: float = 0.0

    PROACTIVE_ENABLED: bool = True
    PROACTIVE_IDLE_THRESHOLD_SECONDS: float = 7200.0
    PROACTIVE_COOLDOWN_SECONDS: float = 3600.0
    PROACTIVE_MIN_ENERGY: float = 0.2
    # Roadmap leftovers Item 4b (M3-D2): 0.5 matches turn_taking_probability's
    # own formula midpoint (0.5 + 0.3*D - 0.1*F + 0.2*V at D=0,F=0,V=0), and
    # a state-space sweep (tools/measure/m4b_turn_taking_gate.py) confirmed
    # it blocks 16.9% of the reachable (V,D,F) grid -- inside the [15%,50%]
    # band that makes this a real discriminator rather than decoration, so
    # the default did not need re-siting to the sweep's measured median.
    PROACTIVE_MIN_TURN_PROBABILITY: float = 0.5
    PROACTIVE_DEBUG_THRESHOLD_OVERRIDE: str | None = None

    PSYCH_ALPHA: float = 0.3
    PSYCH_BETA: float = 0.5
    PSYCH_GAMMA: float = 0.2
    PSYCH_DELTA: float = 0.1
    PSYCH_EPSILON: float = 0.03
    PSYCH_LAMBDA_DECAY: float = 0.05

    ACTR_DECAY_RATE: float = 0.5
    ACTR_SPREAD_WEIGHT: float = 1.0
    ACTR_EMOTION_WEIGHT: float = 0.5

    MAUT_W_GOAL: float = 0.35
    MAUT_W_EMOTION: float = 0.25
    MAUT_W_IDENTITY: float = 0.20
    MAUT_W_CONTEXT: float = 0.20
    INTENT_PERSISTENCE_RATE: float = 0.5
    CONTEXT_SHIFT_THRESHOLD: float = 0.6

    REAPPRAISAL_ENABLED: bool = True
    REAPPRAISAL_LEARNING_RATE: float = 0.05

    RUNTIME_AUTO_BOOTSTRAP: bool = True
    RUNTIME_BOOTSTRAP_RETRIES: int = 12
    OLLAMA_REQUIRED_MODELS_STR: str = Field(default="", alias="OLLAMA_REQUIRED_MODELS")

    # P1-6: Q-M2-2 answered SQLite as emergency-only, not a supported runtime
    # mode. A Postgres connection failure at bootstrap defaults to refusing
    # to start under ENVIRONMENT=production rather than silently downgrading
    # (losing pgvector) into a mode nobody chose to run. Set true only for a
    # deliberate degraded deployment, not as a standing default.
    ALLOW_SQLITE_FALLBACK: bool = False
    # Written by runtime_bootstrap.py (a different process than the backend
    # API) when the SQLite fallback is entered, so /health can surface it,
    # and removed again once Postgres answers. Same pattern as
    # VISION_HEALTH_FILE below.
    #
    # Scope, stated plainly: bootstrap runs inside the brain_agent container
    # under docker-compose.prod.yml, while /health is served by main.py
    # elsewhere, so this path only carries the signal between them if it is
    # on a shared mount. It is not the primary alarm and is not relied on to
    # be -- the ERROR log and the production fail-closed are, and both work
    # regardless of topology. Point this at a shared volume to get the
    # /health flag in a multi-container deployment.
    SQLITE_FALLBACK_HEALTH_FILE: str = "/tmp/sqlite_fallback_active"  # nosec B108 - shared-volume health signal, not a secret path

    SOVITS_URL: str = "http://127.0.0.1:9871"
    STT_LANGUAGE: str = "en"
    TTS_LANGUAGE: str = "en"

    CUSTOM_GPT_PATH: str = "GPT_weights/ai_friend_voice.ckpt"
    CUSTOM_SOVITS_PATH: str = "SoVITS_weights/ai_friend_voice.pth"
    VOICE_WEIGHT_LOAD_RETRIES: int = 3
    VOICE_FILLER_HYDRATE_ON_STARTUP: bool = True
    VOICE_TTS_MOCK: bool = False

    # Vision / VLM Configuration
    VLM_MODEL: str = "moondream"
    VLM_ENABLED: bool = True
    VLM_APPRAISAL_INTERVAL: float = 5.0
    VLM_HABITUATION_THRESHOLD: float = 0.005
    VLM_PROMPT: str = (
        "Describe what you see in this image briefly. Focus on what the user is doing."
    )
    # Touched on every successful frame capture so a container healthcheck can
    # probe the real path rather than mere process liveness (see finding E1).
    VISION_HEALTH_FILE: str = "/tmp/vision_agent_healthy"  # nosec B108 - same as SQLITE_FALLBACK_HEALTH_FILE above

    # P1-7: measured (this repo's audit/) that two resident 3B models roughly
    # halve each other's decode rate on one GPU/one Ollama endpoint -- the
    # VLM and the conversational LLM otherwise contend on every turn. Since
    # OLLAMA_MAX_LOADED_MODELS=1 was measured to trade that for a ~2s
    # model-swap on every contention event (worse for VLM_APPRAISAL_INTERVAL-
    # frequency calls than the throughput hit it removes), the fix is
    # scheduling, not eviction: suspend VLM appraisal for the duration of a
    # cognitive turn instead.
    VISION_SUSPEND_DURING_TURN: bool = True
    # M3-R3: the VLM caller had no circuit breaker, so a failing Ollama (or
    # missing VLM model) was retried every capture tick with a full base64
    # frame. Modeled on the Rust CircuitBreaker in
    # crates/voice-agent/src/main.rs -- consecutive-failure threshold, then a
    # cooldown before the next real attempt.
    VLM_BREAKER_FAILURE_THRESHOLD: int = 3
    VLM_BREAKER_COOLDOWN_S: float = 30.0

    # M3-A10: `_calculate_user_distance`'s pinhole-camera formula needs a
    # focal length in pixels, not just a face-width ratio -- the previous
    # `ASSUMED_FACE_WIDTH_M / (face_width_px / image_width_px)` implicitly
    # set focal_px == image_width, an unstated assumption equivalent to a
    # fixed ~53 degree horizontal FOV regardless of the real camera. These
    # two are calibrated together: VISION_FOCAL_PX is the focal length at
    # VISION_FOCAL_REFERENCE_WIDTH_PX, the width both CameraLink and
    # ScreenLink resize captures down to (`_compress_frame`, links.py) before
    # anything downstream sees them. The default assumes a ~60 degree
    # horizontal FOV, a typical laptop webcam spec, and is a placeholder
    # order-of-magnitude choice, not a measured value (see CLAUDE.md's
    # integrity constraints). Calibration note: place a face of known width
    # (e.g. 0.15m) at a known distance (e.g. 0.5m) in frame, read the logged
    # face_width_px, and solve
    # VISION_FOCAL_PX = (face_width_px * distance_m) / FACE_WIDTH_M,
    # scaled to VISION_FOCAL_REFERENCE_WIDTH_PX if measured at another width.
    VISION_FOCAL_PX: float = 443.0
    VISION_FOCAL_REFERENCE_WIDTH_PX: int = 512

    # Roadmap leftovers Item 1 (P4-12, M5-P3 MEASURED): nomic-embed-text,
    # 768-dim, per-item embedding cost at batch 1 (warm) ~19ms, batch 8
    # 9.2ms, batch 32 8.0ms -- 32 is the measured knee, not a guess.
    # `MemoryStore.get_embeddings` chunks at this size.
    EMBEDDING_BATCH_SIZE: int = 32

    # P3-1: salience-gated visual episodic memory. Screen captures are far
    # more privacy-sensitive than camera captures -- a screen can show
    # anything open on the machine, not just the user's face -- so
    # screen-sourced visual traces get a hard TTL instead of the graded
    # ACT-R fade camera-sourced ones get through `memories`. This is a
    # privacy boundary, not temperament, so it is a deployment setting here
    # rather than a PersonaProfile field.
    VISUAL_SCREEN_TRACE_TTL_H: float = 24.0
    # A visual trace is stored only when the frame is perceptually novel
    # (VisualAppraisalService.last_frame_was_novel), the appraisal produced
    # a description, and the moment was affectively significant -- current
    # arousal or |valence| clears one of these two thresholds. Unmeasured
    # placeholders (CLAUDE.md integrity constraints): both are a modest
    # deviation from the neutral baseline (arousal=0.5, valence=0.0), not
    # tuned values.
    VISUAL_MEMORY_AROUSAL_THRESHOLD: float = 0.55
    VISUAL_MEMORY_VALENCE_THRESHOLD: float = 0.15

    # Half-life of a phasic hormone burst, in seconds. Real phasic bursts last
    # only hundreds of milliseconds; these are the *felt* afterglow at
    # conversational timescale, so both are deliberately much slower than
    # biology and much faster than the ALMA mood decay (PSYCH_LAMBDA_DECAY,
    # hours). These are now only the
    # *defaults* a PersonaProfile inherits when a persona file does not name
    # them (see app/persona/profile.py); AgentState reads the persona's values,
    # not these. Cortisol's is the longer of the two deliberately: an acute
    # stress response outlasts a reward burst.
    DOPAMINE_PHASIC_HALFLIFE_S: float = 90.0
    CORTISOL_PHASIC_HALFLIFE_S: float = 600.0

    STT_MODEL_SIZE: str = "small"
    STT_DEVICE: str = "cpu"

    SAMPLE_RATE: int = 32000
    BINARY_SUBJECTS: list[str] = ["audio.inbound", "audio.stream"]
    SYSTEM_TICK_INTERVAL: int = 60
    FEEDBACK_ALPHA: float = 0.70
    MAX_VOICE_QUEUE_SIZE: int = 10
    VOICE_SYNTH_CONCURRENCY: int = 1
    TRANSPORT_AUDIO_QUEUE_SIZE: int = 256
    VOICE_FILLER_MIN_INTERVAL_SECONDS: float = 1.5
    VOICE_FILLER_MAX_PLAYBACK_BACKLOG: int = 4
    VOICE_FILLER_THRESHOLD: float = 0.25

    INTENT_THRESHOLD: float = 0.75
    INTENT_STABILITY: int = 3
    # Reduced to 4 for smoother macOS/CPU performance during high-throughput research
    STT_WHISPER_QUEUE_SIZE: int = 4
    STT_PERCEPTION_QUEUE_SIZE: int = 4

    GRAPH_CACHE_TTL: int = 300
    MIN_PERCEPTION_CONFIDENCE: float = 0.55
    STATE_SENSORY_WEIGHT: float = 0.20
    STATE_SENSORY_PERSIST_INTERVAL: float = 2.0

    # L5: pydantic-settings already validates *type* (a non-numeric
    # TOKEN_RATE_LIMIT_WINDOW_SECONDS fails to load at all), but not *range* -
    # a negative timeout or a zero halflife loads fine and only breaks
    # something at runtime. This is deliberately a short, curated list of
    # fields where an out-of-range value causes a specific concrete failure
    # (division by zero in decay math, a busy-loop tick, a rate limiter that
    # blocks everything or nothing), not an exhaustive sweep of every numeric
    # setting - most of the ~40 others have no failure mode worth guarding.
    _POSITIVE_FLOAT_FIELDS = (
        "DOPAMINE_PHASIC_HALFLIFE_S",
        "CORTISOL_PHASIC_HALFLIFE_S",
        "TOKEN_RATE_LIMIT_WINDOW_SECONDS",
        "LLM_STREAM_MAX_SECONDS",
    )
    _NON_NEGATIVE_FLOAT_FIELDS = ("ACTR_DECAY_RATE",)
    _POSITIVE_INT_FIELDS = (
        "SYSTEM_TICK_INTERVAL",
        "TOKEN_RATE_LIMIT_MAX_REQUESTS",
        "MAX_VOICE_QUEUE_SIZE",
        "VOICE_SYNTH_CONCURRENCY",
        "TRANSPORT_AUDIO_QUEUE_SIZE",
        "STT_WHISPER_QUEUE_SIZE",
        "STT_PERCEPTION_QUEUE_SIZE",
    )

    @model_validator(mode="after")
    def validate_numeric_ranges(self):
        for name in self._POSITIVE_FLOAT_FIELDS:
            value = getattr(self, name)
            if not (value > 0):
                raise ValueError(f"{name} must be > 0 (got {value!r})")
        for name in self._NON_NEGATIVE_FLOAT_FIELDS:
            value = getattr(self, name)
            if value < 0:
                raise ValueError(f"{name} must be >= 0 (got {value!r})")
        for name in self._POSITIVE_INT_FIELDS:
            value = getattr(self, name)
            if value < 1:
                raise ValueError(f"{name} must be >= 1 (got {value!r})")
        if not (0 < self.QDRANT_PORT <= 65535):
            raise ValueError(f"QDRANT_PORT must be a valid port (got {self.QDRANT_PORT!r})")
        return self

    # #162: the literal placeholder strings this repo's own `.env.example`
    # ships. Deliberately this narrow set, not a generic "looks like a weak
    # password" heuristic -- a heuristic strong enough to catch real weak
    # passwords is also strong enough to reject a legitimate one that happens
    # to contain a common word, and a false positive here means production
    # refuses to boot. This only catches the exact templates a deployment gets
    # by copying `.env.example` and forgetting to edit it, which is the
    # failure mode the issue describes.
    _PLACEHOLDER_SECRET_MARKERS = (
        "your_password_here",
        "your_graph_password_here",
        "your_api_key_here",
        "your_api_secret_here",
    )
    # P0-1: the LiveKit dev credential that was committed in livekit.yaml's
    # `keys:` block (now removed). Catching it here too means a deployment
    # still carrying it in LIVEKIT_API_KEY/SECRET -- e.g. via an old .env
    # copied forward -- also refuses to boot.
    #
    # These are matched WHOLE, not as substrings, unlike the markers above.
    # "devkey" is only six characters; substring-matching it would reinstate
    # exactly the heuristic the comment above rejects, and a false positive
    # here means production refuses to start. A real credential is never
    # equal to one of these, so equality is both sufficient and safe.
    _PLACEHOLDER_SECRET_EXACT = (
        "devkey",
        "secretsecretsecret",
    )
    # Only the fields that gate a real, network-reachable service if left at
    # the shipped placeholder -- Postgres/Neo4j auth and the LiveKit room
    # credentials. Optional integrations (Gemini, ElevenLabs, Porcupine) are
    # deliberately excluded: a placeholder there disables a feature, it
    # doesn't expose one.
    _SECRET_BEARING_FIELDS = (
        "DATABASE_URL",
        "NEO4J_PASSWORD",
        "NEO4J_AUTH",
        "LIVEKIT_API_KEY",
        "LIVEKIT_API_SECRET",
    )

    @model_validator(mode="after")
    def validate_no_placeholder_secrets_in_production(self):
        if self.ENVIRONMENT != "production":
            return self
        for name in self._SECRET_BEARING_FIELDS:
            value = getattr(self, name, None)
            if not value:
                continue
            if any(
                marker in value for marker in self._PLACEHOLDER_SECRET_MARKERS
            ) or value.strip() in self._PLACEHOLDER_SECRET_EXACT:
                raise ValueError(
                    f"{name} still contains a placeholder value from .env.example "
                    "-- refusing to start with ENVIRONMENT=production. Set a real "
                    "secret before deploying."
                )
        return self

    @model_validator(mode="after")
    def set_defaults(self):
        if not self.LLM_CHAT_MODEL:
            self.LLM_CHAT_MODEL = self.LLM_FAST_MODEL
        if not self.LLM_REFLECTION_MODEL:
            self.LLM_REFLECTION_MODEL = self.LLM_CHAT_MODEL
        return self

    @field_validator("LIVEKIT_URL")
    @classmethod
    def normalize_livekit_scheme(cls, v: str) -> str:
        """E3: both the frontend and transport_agent hand this straight to
        LiveKit's room.connect(), which needs ws(s)://, not http(s)://. Normalize
        here so an existing .env carrying the old http:// default (from before
        this fix) self-heals instead of requiring every deployment to be
        manually edited.
        """
        if v.startswith("https://"):
            return "wss://" + v[len("https://") :]
        if v.startswith("http://"):
            return "ws://" + v[len("http://") :]
        return v

    @field_validator("LIVEKIT_PUBLIC_URL")
    @classmethod
    def normalize_livekit_public_scheme(cls, v: str) -> str:
        if v.startswith("https://"):
            return "wss://" + v[len("https://") :]
        if v.startswith("http://"):
            return "ws://" + v[len("http://") :]
        return v

    @field_validator("EMBEDDING_BATCH_SIZE")
    @classmethod
    def validate_embedding_batch_size(cls, v: int) -> int:
        if v <= 0:
            raise ValueError("EMBEDDING_BATCH_SIZE must be positive")
        return v

    @field_validator("VISUAL_SCREEN_TRACE_TTL_H")
    @classmethod
    def validate_visual_trace_ttl(cls, v: float) -> float:
        if v <= 0:
            raise ValueError("VISUAL_SCREEN_TRACE_TTL_H must be positive")
        return v

    @field_validator(
        "VISUAL_MEMORY_AROUSAL_THRESHOLD", "VISUAL_MEMORY_VALENCE_THRESHOLD"
    )
    @classmethod
    def validate_visual_memory_threshold(cls, v: float) -> float:
        if not 0.0 <= v <= 1.0:
            raise ValueError("visual-memory thresholds must be between 0 and 1")
        return v

    # F4: these were previously computed in ConfigMeta.__getattr__, which
    # special-cased these two names and silently delegated every other
    # attribute straight to config_instance - a surprising place to look for
    # derived config, and easy to miss when adding a third computed value.
    # Real computed_field properties are visible on AppSettings itself, so
    # ConfigMeta's job shrinks to "look up the instance," nothing more.
    @computed_field  # type: ignore[prop-decorator]
    @property
    def ALLOWED_ORIGINS(self) -> list[str]:
        return self.ALLOWED_ORIGINS_STR.split(",")

    @computed_field  # type: ignore[prop-decorator]
    @property
    def OLLAMA_REQUIRED_MODELS(self) -> list[str]:
        if self.OLLAMA_REQUIRED_MODELS_STR.strip():
            return [
                model.strip()
                for model in self.OLLAMA_REQUIRED_MODELS_STR.split(",")
                if model.strip()
            ]
        # set_defaults() (a model_validator) already backfills these from
        # LLM_FAST_MODEL, but that invariant isn't visible to mypy here.
        models = [
            self.LLM_CHAT_MODEL or self.LLM_FAST_MODEL,
            self.LLM_FAST_MODEL,
            self.LLM_REFLECTION_MODEL or self.LLM_FAST_MODEL,
            "nomic-embed-text",
        ]
        if self.VLM_ENABLED:
            models.append(self.VLM_MODEL)
        return list(dict.fromkeys(models))


config_instance = AppSettings()


class ConfigMeta(type):
    def __getattr__(cls, name):
        return getattr(config_instance, name)


class Config(metaclass=ConfigMeta):
    @staticmethod
    def validate():
        # Validation is now handled by Pydantic during instantiation.
        pass
