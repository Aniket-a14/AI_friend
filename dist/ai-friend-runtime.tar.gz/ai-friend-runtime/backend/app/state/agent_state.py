"""
Agent State — PAD + Relational Framework (psychological_layer.md §2).

Affective dimensions: Valence (V), Arousal (Ar), Dominance (D)
  — Mehrabian & Russell (1974)

Relational dimensions: Trust (T), Attachment (At)
  — Marsh (1994) for trust, Bowlby for attachment

State updates: ALMA mood-pull + exponential decay (Gebhard, 2005)
"""

import asyncio
import json
import logging
import math
import os
import sqlite3
import time
from dataclasses import dataclass, field
from datetime import datetime
from typing import TYPE_CHECKING, Any, cast

import redis

from ..config import Config
from ..persona import PersonaProfile
from ..utils.background_tasks import spawn_background

if TYPE_CHECKING:
    from ..cognitive.tom import UserMentalModel


def _default_user_mental_model():
    from ..cognitive.tom import UserMentalModel

    return UserMentalModel()


logger = logging.getLogger(__name__)

# Roadmap §C: recognising a somatic comfort fires a phasic dopamine burst of
# this size. Kept here rather than in somatic.py because it is a property of the
# endocrine response, not of visual recognition -- any future reward channel
# (a warm reply, a resolved goal) should fire through the same mechanism.
SOMATIC_DOPAMINE_SPIKE = 0.25


@dataclass(slots=True)
class AgentState:
    """
    Multidimensional PAD + Relational state for human-like dynamics.

    Backward compatibility: 'mood' and 'energy' are kept as the canonical
    dataclass field names. New PAD vocabulary is provided via properties.
    """

    # PAD Affective Dimensions (Mehrabian & Russell, 1974)
    mood: float = 0.0  # V (Valence): -1.0 to 1.0
    energy: float = 0.5  # Ar (Arousal): 0.0 to 1.0
    dominance: float = 0.5  # D (Dominance): 0.0 to 1.0 — NEW

    # Relational Dimensions
    trust_benevolence: float = 0.5  # Tb (Marsh): 0.0 to 1.0
    trust_competence: float = 0.5  # Tc (Marsh): 0.0 to 1.0
    trust_integrity: float = 0.5  # Ti (Marsh): 0.0 to 1.0
    attachment: float = 0.1  # At (Bowlby): 0.0 to 1.0

    # Interaction Tracking
    interaction_count: int = 0  # For Bowlby attachment frequency
    active_goals: list[str] = field(default_factory=list)
    last_update: datetime = field(default_factory=datetime.now)
    last_user_interaction: float = field(default_factory=time.time)
    # Phase 3.1: was a plain `StateService._last_proactive_attempt` instance
    # attribute, persisted nowhere -- every restart reset the proactive
    # cooldown to expired, and the two OS processes that each own a
    # `StateService` (see `apply_external_state`'s docstring) never agreed on
    # it. 0.0 (not "now") on purpose: a fresh agent has never attempted a
    # proactive outreach, so the cooldown must read as already satisfied.
    last_proactive_attempt: float = 0.0
    fatigue: float = 0.0  # Metabolic fatigue cycle F(t)
    user_mental_model: "UserMentalModel" = field(
        default_factory=_default_user_mental_model
    )

    # Persistent baseline affect
    baseline_valence: float = 0.0
    baseline_arousal: float = 0.5
    baseline_dominance: float = 0.5

    # Phasic hormone bursts (see the `dopamine` and `cortisol` properties).
    # Stored as a peak plus the moment it was released, so the current level is
    # derived from elapsed time rather than needing a tick to decay it. That
    # keeps the reading correct even if system.tick stalls, and makes decay
    # testable without a clock stub.
    #
    # Deliberately NOT persisted, unlike the baselines above. Both half-lives
    # are minutes-scale, so a burst is already within rounding distance of zero
    # by the time any realistic restart completes; carrying it across one would
    # preserve a value that no longer means anything. Restoring a state with no
    # burst is also the safe direction -- peak defaults to 0.0, which reads as
    # "nothing outstanding" rather than as a stale reward or a stale threat. If
    # a future hormone decays on an hours-scale, that one *will* need
    # persisting.
    dopamine_phasic_peak: float = 0.0
    dopamine_phasic_at: float = field(default_factory=time.time)
    cortisol_phasic_peak: float = 0.0
    cortisol_phasic_at: float = field(default_factory=time.time)

    # Half-lives are temperament, not deployment settings: how long a reward
    # glows and how long a fright lingers are among the most recognisable things
    # about a person. StateService seeds these from the PersonaProfile; the
    # defaults reproduce the previous Config-driven behaviour exactly.
    dopamine_halflife_s: float = 90.0
    cortisol_halflife_s: float = 600.0

    # --- Affect Split Properties ---
    @property
    def personality_baseline_affect(self) -> dict[str, float]:
        """Persistent slow-evolving personality baseline affect."""
        return {
            "valence": self.baseline_valence,
            "arousal": self.baseline_arousal,
            "dominance": self.baseline_dominance,
        }

    @personality_baseline_affect.setter
    def personality_baseline_affect(self, value: dict[str, float]):
        self.baseline_valence = value.get("valence", self.baseline_valence)
        self.baseline_arousal = value.get("arousal", self.baseline_arousal)
        self.baseline_dominance = value.get("dominance", self.baseline_dominance)

    @property
    def short_term_affect(self) -> dict[str, float]:
        """Transient highly reactive short-term affect."""
        return {
            "valence": self.mood,
            "arousal": self.energy,
            "dominance": self.dominance,
        }

    @short_term_affect.setter
    def short_term_affect(self, value: dict[str, float]):
        self.mood = value.get("valence", self.mood)
        self.energy = value.get("arousal", self.energy)
        self.dominance = value.get("dominance", self.dominance)

    # --- PAD Property Aliases (§2.1) ---
    @property
    def valence(self) -> float:
        """PAD Valence (V) — maps to 'mood'."""
        return self.mood

    @valence.setter
    def valence(self, value: float):
        self.mood = value

    @property
    def arousal(self) -> float:
        """PAD Arousal (Ar) — maps to 'energy' + fatigue-induced restlessness."""
        fatigue_restlessness = 0.2 * self.fatigue
        return max(0.0, min(1.0, self.energy + fatigue_restlessness))

    @arousal.setter
    def arousal(self, value: float):
        self.energy = value

    @property
    def trust(self) -> float:
        """PAD Trust (T) — maps to average of Benevolence, Competence, and Integrity."""
        return (
            self.trust_benevolence + self.trust_competence + self.trust_integrity
        ) / 3.0

    @trust.setter
    def trust(self, value: Any):
        if isinstance(value, dict):
            self.trust_benevolence = float(
                value.get("trust_benevolence", self.trust_benevolence)
            )
            self.trust_competence = float(
                value.get("trust_competence", self.trust_competence)
            )
            self.trust_integrity = float(
                value.get("trust_integrity", self.trust_integrity)
            )
        elif isinstance(value, (list, tuple)) and len(value) == 3:
            self.trust_benevolence = float(value[0])
            self.trust_competence = float(value[1])
            self.trust_integrity = float(value[2])
        else:
            try:
                scalar_value = float(value)
                self.trust_benevolence = scalar_value
                self.trust_competence = scalar_value
                self.trust_integrity = scalar_value
            except (ValueError, TypeError):
                pass

    # --- Endocrine Hormonal Properties (Tier-5 Physiological Control) ---
    @staticmethod
    def _decayed(peak: float, released_at: float, half_life: float) -> float:
        """Exponential decay of a phasic burst from `peak` toward zero.

        Shared by both hormones so the two cannot drift apart: a fix to the
        decay maths that only landed on one of them would be a subtle and
        long-lived bug, since each reads plausibly on its own.
        """
        if peak <= 0.0:
            return 0.0
        half_life = max(1e-6, float(half_life))
        elapsed = max(0.0, time.time() - released_at)
        return peak * math.exp(-math.log(2.0) * elapsed / half_life)

    @staticmethod
    def _burst_amount(amount: Any, hormone: str) -> float:
        """Validate a release amount, returning 0.0 for anything unusable."""
        try:
            amount = float(amount)
        except (TypeError, ValueError):
            return 0.0
        # NaN survives `float()` and then defeats every comparison downstream:
        # `nan <= 0.0` is False, so it passes the positivity guard, and
        # `min(1.0, nan)` returns 1.0 -- a NaN input would fire a *maximum*
        # burst. Infinity takes the same route. Both are caller bugs, not
        # signals, and a maximum stress response is the worst possible reading
        # of a malformed one.
        if not math.isfinite(amount):
            logger.warning("[Endocrine] Ignoring non-finite %s release %r.", hormone, amount)
            return 0.0
        return max(0.0, amount)

    @property
    def cortisol_tonic(self) -> float:
        """Background stress tone: inverse valence plus a fatigue contribution.

        This is the whole of what `cortisol` used to be. Like tonic dopamine it
        is a pure function of current affect, so it has no memory: the moment
        valence recovers, the stress is gone.
        """
        base_cortisol = 0.5 - (self.valence / 2.0)
        fatigue_contribution = 0.3 * self.fatigue
        return max(0.0, min(1.0, base_cortisol + fatigue_contribution))

    @property
    def cortisol_phasic(self) -> float:
        """The decaying remainder of recent acute stress.

        The tonic term is derived entirely from valence, which made stress
        unable to outlive its cause -- recover your mood and the alarm stops,
        instantly and completely. That is not how a threat response works. The
        HPA axis releases cortisol on a slower course than a dopamine burst and
        it clears slower too, which is why the default half-life here is
        markedly longer than dopamine's: being frightened has a hangover, being
        pleased mostly does not.
        """
        return self._decayed(
            self.cortisol_phasic_peak, self.cortisol_phasic_at, self.cortisol_halflife_s
        )

    @property
    def cortisol(self) -> float:
        """
        Stress hormone: tonic tone plus any decaying acute burst.
        High cortisol → rigid/defensive behavior (low LLM temperature).
        Low cortisol → relaxed/creative behavior (higher temperature).
        Range: 0.0 (fully relaxed) to 1.0 (maximum stress).

        With no burst outstanding this is exactly the historical derived value,
        so every existing reading and test is unaffected.
        """
        return max(0.0, min(1.0, self.cortisol_tonic + self.cortisol_phasic))

    def release_cortisol(self, amount: float) -> float:
        """Fire an acute stress response, returning the new cortisol level.

        The mirror of `release_dopamine`, and the reason the endocrine layer is
        no longer one-sided. Tonic cortisol and tonic dopamine are perfectly
        anti-correlated by construction -- both are functions of valence alone,
        one rising exactly as the other falls -- so before this the agent could
        not be *both* stressed and rewarded, a combination that describes a
        great deal of ordinary experience. Phasic dopamine already broke that
        coupling in one direction; this breaks it in the other.
        """
        amount = self._burst_amount(amount, "cortisol")
        if amount <= 0.0:
            return self.cortisol

        target_total = min(1.0, self.cortisol + amount)
        # Relative to the tonic floor, so that floor stays free to drift with
        # affect underneath a decaying burst instead of being double-counted.
        self.cortisol_phasic_peak = max(0.0, target_total - self.cortisol_tonic)
        self.cortisol_phasic_at = time.time()
        return self.cortisol

    @property
    def dopamine_tonic(self) -> float:
        """Background reward tone: positive valence × arousal.

        This is the whole of what `dopamine` used to be. It tracks the ongoing
        affective state instantaneously and has no memory of its own.
        """
        return max(0.0, min(1.0, max(0.0, self.valence) * self.arousal))

    @property
    def dopamine_phasic(self) -> float:
        """The decaying remainder of recent reward bursts.

        Real dopamine signalling separates a slow tonic level from fast phasic
        bursts on reward (Grace 1991; Schultz's reward-prediction-error work).
        The tonic term above cannot represent "something good happened thirty
        seconds ago and I am still lit up" -- being a pure function of current
        valence and arousal, it forgets instantly. This is that memory, decaying
        exponentially from the peak toward zero.
        """
        return self._decayed(
            self.dopamine_phasic_peak, self.dopamine_phasic_at, self.dopamine_halflife_s
        )

    @property
    def dopamine(self) -> float:
        """
        Reward hormone: tonic tone plus any decaying phasic burst.
        High dopamine → exploratory/playful behavior (higher top_p).
        Low dopamine → conservative/flat behavior (lower top_p).
        Range: 0.0 (no reward signal) to 1.0 (peak reward).

        With no burst outstanding this is exactly the historical derived value
        (`max(0, V) * Ar`), so every existing reading and test is unaffected.
        """
        return max(0.0, min(1.0, self.dopamine_tonic + self.dopamine_phasic))

    def release_dopamine(self, amount: float) -> float:
        """Fire a phasic burst, returning the new total dopamine level.

        Implements the roadmap's `D_t = min(1.0, D_{t-1} + amount)`
        (`docs/cvs4_architecture_roadmap.md` §C) literally, which the previous
        derived-only property could not: with dopamine computed purely from
        valence and arousal there was no `D_{t-1}` to add to, and the only way
        to move it was to move mood itself.

        The burst is stored relative to the tonic floor, so that floor stays
        free to drift with affect underneath a decaying burst instead of being
        double-counted into it.
        """
        amount = self._burst_amount(amount, "dopamine")
        if amount <= 0.0:
            return self.dopamine

        target_total = min(1.0, self.dopamine + amount)
        self.dopamine_phasic_peak = max(0.0, target_total - self.dopamine_tonic)
        self.dopamine_phasic_at = time.time()
        return self.dopamine


class StateService:
    """Manages Internal State continuity and Neo4j persistence."""

    def __init__(
        self,
        graph_store=None,
        db_path="state_cache.db",
        redis_host="127.0.0.1",
        redis_port=6379,
        publish_cb=None,
        persona: "PersonaProfile | None" = None,
    ):
        self.graph = graph_store
        self.db_path = db_path
        self.publish_cb = publish_cb
        # Temperament has to exist before the state it initialises.
        self.persona = persona or PersonaProfile.load()
        self.current_state = AgentState(
            baseline_valence=self.persona.baseline_valence,
            baseline_arousal=self.persona.baseline_arousal,
            baseline_dominance=self.persona.baseline_dominance,
            # A friend starts where its author placed it, then lives its own way
            # from there -- these are seeds, not settings (Tier.ADAPTIVE).
            mood=self.persona.baseline_valence,
            energy=self.persona.baseline_arousal,
            dominance=self.persona.baseline_dominance,
            trust_benevolence=self.persona.initial_trust,
            trust_competence=self.persona.initial_trust,
            trust_integrity=self.persona.initial_trust,
            attachment=self.persona.initial_attachment,
            # Named rather than **-unpacked: a generic dict[str, float] spread
            # makes mypy check every AgentState field for float-compatibility,
            # not just these two.
            dopamine_halflife_s=self.persona.hormone_halflives()["dopamine_halflife_s"],
            cortisol_halflife_s=self.persona.hormone_halflives()["cortisol_halflife_s"],
        )
        self.last_speculative_intent = None  # Transient sensory state
        # A2: serializes short-term affect mutation so the fire-and-forget
        # System-2 semantic-drift task cannot clobber a fresher appraisal.
        self._state_lock = asyncio.Lock()
        # Separate from `_state_lock` on purpose. This one serializes the *write
        # ordering* in `persist_state`, which now yields at each `to_thread`
        # dispatch; callers reach `persist_state` from methods already holding
        # `_state_lock`, so reusing it would deadlock.
        self._persist_lock = asyncio.Lock()

        # P4-8: strong-reference holder for the fire-and-forget
        # state.broadcast publish below.
        self._background_tasks: set[asyncio.Task] = set()

        # Connect to Redis
        self.redis_client: redis.Redis | None
        try:
            self.redis_client = redis.Redis(
                host=redis_host,
                port=redis_port,
                db=0,
                socket_connect_timeout=1.0,
                decode_responses=True,
            )
            self.redis_client.ping()
        except Exception:
            self.redis_client = None

        self._initialize_sqlite()

        # --- Psychological Coefficients (§2.4) ---
        # These are the agent's temperament, so they come from the persona rather
        # than from process-global config. `PersonaProfile.from_config()` reads
        # the same PSYCH_* settings as before, so an unconfigured deployment is
        # unchanged; a persona file overrides them per-friend.
        coefficients = self.persona.coefficients()
        self.alpha = coefficients["alpha"]  # Valence drift rate
        self.beta = coefficients["beta"]  # Arousal response rate
        self.gamma = coefficients["gamma"]  # Dominance stability
        self.delta = coefficients["delta"]  # Trust change rate (Marsh)
        self.epsilon = coefficients["epsilon"]  # Attachment growth rate (Bowlby)
        self.lambda_decay = coefficients["lambda_decay"]  # ALMA decay

        # Legacy coefficients (kept for idle evolution)
        self.trust_baseline = 0.5
        self.sensory_weight = getattr(Config, "STATE_SENSORY_WEIGHT", 0.20)
        self.min_perception_confidence = getattr(
            Config, "MIN_PERCEPTION_CONFIDENCE", 0.55
        )
        self.sensory_persist_interval = getattr(
            Config, "STATE_SENSORY_PERSIST_INTERVAL", 2.0
        )
        self._last_sensory_persist = 0.0

    def _initialize_sqlite(self):
        if self.db_path != ":memory:":
            db_dir = os.path.dirname(os.path.abspath(self.db_path))
            if db_dir:
                os.makedirs(db_dir, exist_ok=True)
        conn = sqlite3.connect(self.db_path)
        with conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS agent_state (
                    agent_name TEXT PRIMARY KEY,
                    mood REAL,
                    energy REAL,
                    dominance REAL,
                    trust_benevolence REAL,
                    trust_competence REAL,
                    trust_integrity REAL,
                    trust REAL,
                    attachment REAL,
                    fatigue REAL,
                    last_user_interaction REAL,
                    interaction_count INTEGER,
                    inferred_valence REAL,
                    inferred_arousal REAL,
                    implied_goals TEXT,
                    known_concepts TEXT,
                    baseline_valence REAL DEFAULT 0.0,
                    baseline_arousal REAL DEFAULT 0.5,
                    baseline_dominance REAL DEFAULT 0.5,
                    last_proactive_attempt REAL DEFAULT 0.0,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            # `CREATE TABLE IF NOT EXISTS` does not add a column to a table
            # that already exists from before this field did. Migrated
            # separately, tolerating the column already being there (a fresh
            # DB just created it above) rather than checking pragma_table_info
            # first -- SQLite's own error is the simplest source of truth.
            try:
                conn.execute(
                    "ALTER TABLE agent_state ADD COLUMN last_proactive_attempt "
                    "REAL DEFAULT 0.0"
                )
            except sqlite3.OperationalError as exc:
                if "duplicate column name" not in str(exc):
                    raise
        conn.close()

    async def hydrate_state(self, agent_name: str = "my friend"):
        """Loads state from Redis or local SQLite cache.

        Takes `_state_lock` like every other mutation path. Hydration is called
        once from `CognitiveService.initialize`, so today nothing races it --
        but it writes roughly twenty `current_state` fields one at a time, and
        it was the only writer not holding the lock. A future caller that
        re-hydrates mid-session would interleave with the fire-and-forget
        System-2 appraisal and leave a state that is half restored and half
        appraised, which is precisely the failure the lock exists to prevent.
        """
        logger.info(f"[State] Hydrating {agent_name} from Redis/SQLite...")
        async with self._state_lock:
            await self._hydrate_locked(agent_name)

    async def _hydrate_locked(self, agent_name: str):
        # 1. Try Redis
        if self.redis_client:
            try:
                # Off the loop: synchronous client, and a dead Redis costs a
                # full connect timeout here rather than returning quickly.
                # redis-py's sync Redis shares stubs with the async client, so
                # hgetall is typed Awaitable[dict] | dict even on this
                # always-sync client -- cast to the runtime-true shape.
                data = cast(
                    "dict[str, str]",
                    await asyncio.to_thread(
                        self.redis_client.hgetall, f"state:{agent_name}"
                    ),
                )
                if data:
                    self.current_state.mood = float(data.get("mood", 0.0))
                    self.current_state.energy = float(data.get("energy", 0.5))
                    self.current_state.dominance = float(data.get("dominance", 0.5))
                    self.current_state.trust_benevolence = float(
                        data.get("trust_benevolence", 0.5)
                    )
                    self.current_state.trust_competence = float(
                        data.get("trust_competence", 0.5)
                    )
                    self.current_state.trust_integrity = float(
                        data.get("trust_integrity", 0.5)
                    )
                    self.current_state.attachment = float(data.get("attachment", 0.1))
                    self.current_state.fatigue = float(data.get("fatigue", 0.0))
                    self.current_state.last_user_interaction = float(
                        data.get("last_user_interaction", time.time())
                    )
                    self.current_state.last_proactive_attempt = float(
                        data.get("last_proactive_attempt", 0.0)
                    )
                    self.current_state.interaction_count = int(
                        data.get("interaction_count", 0)
                    )
                    self.current_state.user_mental_model.inferred_valence = float(
                        data.get("inferred_valence", 0.0)
                    )
                    self.current_state.user_mental_model.inferred_arousal = float(
                        data.get("inferred_arousal", 0.5)
                    )
                    self.current_state.user_mental_model.implied_goals = json.loads(
                        data.get("implied_goals", "[]")
                    )
                    self.current_state.user_mental_model.known_concepts = json.loads(
                        data.get("known_concepts", "[]")
                    )
                    self.current_state.baseline_valence = float(
                        data.get("baseline_valence", 0.0)
                    )
                    self.current_state.baseline_arousal = float(
                        data.get("baseline_arousal", 0.5)
                    )
                    self.current_state.baseline_dominance = float(
                        data.get("baseline_dominance", 0.5)
                    )
                    logger.debug("[State] Hydrated successfully from Redis.")
                    return
            except Exception as e:
                logger.warning(f"Failed to hydrate state from Redis: {e}")

        # 2. Try SQLite
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.row_factory = sqlite3.Row
                cursor = conn.cursor()
                cursor.execute(
                    "SELECT * FROM agent_state WHERE agent_name = ?", (agent_name,)
                )
                row = cursor.fetchone()
                if row:
                    self.current_state.mood = row["mood"]
                    self.current_state.energy = row["energy"]
                    self.current_state.dominance = row["dominance"]
                    self.current_state.trust_benevolence = row["trust_benevolence"]
                    self.current_state.trust_competence = row["trust_competence"]
                    self.current_state.trust_integrity = row["trust_integrity"]
                    self.current_state.attachment = row["attachment"]
                    self.current_state.fatigue = row["fatigue"]
                    self.current_state.last_user_interaction = row[
                        "last_user_interaction"
                    ]
                    self.current_state.last_proactive_attempt = row[
                        "last_proactive_attempt"
                    ] or 0.0
                    self.current_state.interaction_count = row["interaction_count"]
                    self.current_state.user_mental_model.inferred_valence = row[
                        "inferred_valence"
                    ]
                    self.current_state.user_mental_model.inferred_arousal = row[
                        "inferred_arousal"
                    ]
                    self.current_state.user_mental_model.implied_goals = json.loads(
                        row["implied_goals"] or "[]"
                    )
                    self.current_state.user_mental_model.known_concepts = json.loads(
                        row["known_concepts"] or "[]"
                    )
                    self.current_state.baseline_valence = row["baseline_valence"]
                    self.current_state.baseline_arousal = row["baseline_arousal"]
                    self.current_state.baseline_dominance = row["baseline_dominance"]
                    logger.debug("[State] Hydrated successfully from SQLite.")
                    return
        except Exception as e:
            logger.error(f"Failed to hydrate state from SQLite: {e}")

        # 3. Fallback to Neo4j graph_store if self.graph is available
        if self.graph:
            try:
                query = "MATCH (a:Agent {name: $name}) RETURN a"
                res = await self.graph.execute_query(query, {"name": agent_name})
                if res and len(res) > 0:
                    agent_node = res[0].get("a")
                    if agent_node:
                        self.current_state.mood = float(agent_node.get("mood", 0.0))
                        self.current_state.energy = float(agent_node.get("energy", 0.5))
                        self.current_state.dominance = float(
                            agent_node.get("dominance", 0.5)
                        )
                        self.current_state.trust_benevolence = float(
                            agent_node.get("trust_benevolence", 0.5)
                        )
                        self.current_state.trust_competence = float(
                            agent_node.get("trust_competence", 0.5)
                        )
                        self.current_state.trust_integrity = float(
                            agent_node.get("trust_integrity", 0.5)
                        )
                        self.current_state.attachment = float(
                            agent_node.get("attachment", 0.1)
                        )
                        self.current_state.fatigue = float(
                            agent_node.get("fatigue", 0.0)
                        )
                        self.current_state.last_user_interaction = float(
                            agent_node.get("last_user_interaction", time.time())
                        )
                        self.current_state.last_proactive_attempt = float(
                            agent_node.get("last_proactive_attempt", 0.0)
                        )
                        self.current_state.interaction_count = int(
                            agent_node.get("interaction_count", 0)
                        )
                        self.current_state.user_mental_model.inferred_valence = float(
                            agent_node.get("inferred_valence", 0.0)
                        )
                        self.current_state.user_mental_model.inferred_arousal = float(
                            agent_node.get("inferred_arousal", 0.5)
                        )

                        goals = agent_node.get("implied_goals", [])
                        if isinstance(goals, str):
                            try:
                                goals = json.loads(goals)
                            except Exception:
                                goals = []
                        self.current_state.user_mental_model.implied_goals = (
                            goals if isinstance(goals, list) else []
                        )

                        concepts = agent_node.get("known_concepts", [])
                        if isinstance(concepts, str):
                            try:
                                concepts = json.loads(concepts)
                            except Exception:
                                concepts = []
                        self.current_state.user_mental_model.known_concepts = (
                            concepts if isinstance(concepts, list) else []
                        )

                        self.current_state.baseline_valence = float(
                            agent_node.get("baseline_valence", 0.0)
                        )
                        self.current_state.baseline_arousal = float(
                            agent_node.get("baseline_arousal", 0.5)
                        )
                        self.current_state.baseline_dominance = float(
                            agent_node.get("baseline_dominance", 0.5)
                        )
                        logger.debug(
                            "[State] Hydrated successfully from Neo4j fallback."
                        )
            except Exception as e:
                logger.warning(f"Failed fallback hydration from Neo4j: {e}")

    async def apply_external_state(self, data: dict[str, Any]) -> None:
        """P1-5: apply a `state.broadcast` snapshot from another process's
        `StateService` onto this one's `current_state`.

        `subconscious_agent` and `brain_agent` run as separate OS processes
        (`ARCHITECTURE.md`), so they can never share one `AgentState` object
        -- the only channel between them is the mesh. `persist_state` already
        broadcasts the full snapshot on `state.broadcast` after every real
        appraisal/interaction update (rate-limited to
        `STATE_SENSORY_PERSIST_INTERVAL` on the sensory path, uncapped on
        appraisal/event/tick/ToM updates), so it is close to real-time,
        unlike polling `hydrate_state` on a timer -- and it needed no new
        publisher, since the brain already broadcasts this to no listener
        that applied it. `_on_state_broadcast` (subconscious_agent.py)
        called this method's Neo4j-only predecessor and now also calls this.

        Takes `_state_lock` like every other mutation path, same reasoning
        as `hydrate_state`: applied under the lock, a receiver processing a
        broadcast mid fire-and-forget System-2 appraisal cannot leave
        `current_state` half-overwritten and half-appraised.

        Same field set as `_hydrate_locked`'s Redis/SQLite/Neo4j branches,
        applied from the broadcast dict instead -- this is the fourth
        source of the same shape, not a new one.
        """
        async with self._state_lock:
            self.current_state.mood = float(data.get("mood", self.current_state.mood))
            self.current_state.energy = float(
                data.get("energy", self.current_state.energy)
            )
            self.current_state.dominance = float(
                data.get("dominance", self.current_state.dominance)
            )
            self.current_state.trust_benevolence = float(
                data.get("trust_benevolence", self.current_state.trust_benevolence)
            )
            self.current_state.trust_competence = float(
                data.get("trust_competence", self.current_state.trust_competence)
            )
            self.current_state.trust_integrity = float(
                data.get("trust_integrity", self.current_state.trust_integrity)
            )
            self.current_state.attachment = float(
                data.get("attachment", self.current_state.attachment)
            )
            self.current_state.fatigue = float(
                data.get("fatigue", self.current_state.fatigue)
            )
            self.current_state.last_user_interaction = float(
                data.get(
                    "last_user_interaction", self.current_state.last_user_interaction
                )
            )
            self.current_state.last_proactive_attempt = float(
                data.get(
                    "last_proactive_attempt",
                    self.current_state.last_proactive_attempt,
                )
            )
            self.current_state.interaction_count = int(
                data.get("interaction_count", self.current_state.interaction_count)
            )
            self.current_state.user_mental_model.inferred_valence = float(
                data.get(
                    "inferred_valence",
                    self.current_state.user_mental_model.inferred_valence,
                )
            )
            self.current_state.user_mental_model.inferred_arousal = float(
                data.get(
                    "inferred_arousal",
                    self.current_state.user_mental_model.inferred_arousal,
                )
            )
            implied_goals = data.get("implied_goals")
            if isinstance(implied_goals, list):
                self.current_state.user_mental_model.implied_goals = implied_goals
            known_concepts = data.get("known_concepts")
            if isinstance(known_concepts, list):
                self.current_state.user_mental_model.known_concepts = known_concepts
            self.current_state.baseline_valence = float(
                data.get("baseline_valence", self.current_state.baseline_valence)
            )
            self.current_state.baseline_arousal = float(
                data.get("baseline_arousal", self.current_state.baseline_arousal)
            )
            self.current_state.baseline_dominance = float(
                data.get("baseline_dominance", self.current_state.baseline_dominance)
            )

    async def persist_state(self, agent_name: str = "my friend"):
        """Save state to Redis and the local SQLite cache, then broadcast.

        Serialized on `_persist_lock`, which is deliberately *not* `_state_lock`.
        Moving the two writes onto worker threads made `persist_state` yield at
        each `await`, so two overlapping calls could have their writes complete
        in the opposite order and leave an older snapshot on top of a newer one
        -- a regression introduced by the same change that took the blocking
        work off the loop. The lock restores ordering without putting it back:
        it is an asyncio lock, so the rest of the loop keeps running while a
        persist is in flight.

        It cannot be `_state_lock`: callers reach here from methods that already
        hold that lock, so sharing it would deadlock. This one guards *write
        ordering*, not the state fields.
        """
        async with self._persist_lock:
            # One snapshot, taken once, used by both stores. Previously the
            # Redis mapping was built before its await and the SQL parameters
            # after it, so a single call could write two different states to the
            # two backends.
            snapshot = {
            "mood": self.current_state.mood,
            "energy": self.current_state.energy,
            "dominance": self.current_state.dominance,
            "trust_benevolence": self.current_state.trust_benevolence,
            "trust_competence": self.current_state.trust_competence,
            "trust_integrity": self.current_state.trust_integrity,
            "trust": self.current_state.trust,
            "attachment": self.current_state.attachment,
            "fatigue": self.current_state.fatigue,
            "last_user_interaction": self.current_state.last_user_interaction,
            "last_proactive_attempt": self.current_state.last_proactive_attempt,
            "interaction_count": self.current_state.interaction_count,
            "inferred_valence": self.current_state.user_mental_model.inferred_valence,
            "inferred_arousal": self.current_state.user_mental_model.inferred_arousal,
            "baseline_valence": self.current_state.baseline_valence,
            "baseline_arousal": self.current_state.baseline_arousal,
            "baseline_dominance": self.current_state.baseline_dominance,
            }

            # 1. Save to Redis
            if self.redis_client:
                try:
                    # Off-thread: `redis.Redis` is the synchronous client and
                    # this runs on every persist, including the per-turn path.
                    # Called directly it blocks the loop for a network round
                    # trip mid-conversation. redis-py holds a connection pool
                    # and is thread-safe for commands.
                    await asyncio.to_thread(
                        self.redis_client.hset,
                        f"state:{agent_name}",
                        mapping={
                        "mood": str(snapshot["mood"]),
                        "energy": str(snapshot["energy"]),
                        "dominance": str(snapshot["dominance"]),
                        "trust_benevolence": str(snapshot["trust_benevolence"]),
                        "trust_competence": str(snapshot["trust_competence"]),
                        "trust_integrity": str(snapshot["trust_integrity"]),
                        "trust": str(snapshot["trust"]),
                        "attachment": str(snapshot["attachment"]),
                        "fatigue": str(snapshot["fatigue"]),
                        "last_user_interaction": str(snapshot["last_user_interaction"]),
                        "last_proactive_attempt": str(snapshot["last_proactive_attempt"]),
                        "interaction_count": str(snapshot["interaction_count"]),
                        "inferred_valence": str(snapshot["inferred_valence"]),
                        "inferred_arousal": str(snapshot["inferred_arousal"]),
                        "baseline_valence": str(snapshot["baseline_valence"]),
                        "baseline_arousal": str(snapshot["baseline_arousal"]),
                        "baseline_dominance": str(snapshot["baseline_dominance"]),
                        "implied_goals": json.dumps(
                                self.current_state.user_mental_model.implied_goals
                            ),
                            "known_concepts": json.dumps(
                                self.current_state.user_mental_model.known_concepts
                            ),
                        },
                    )
                except Exception as e:
                    logger.warning(f"Failed to persist state to Redis: {e}")

            # 2. Save to SQLite cache
            sqlite_params = (
                agent_name,
            snapshot["mood"],
            snapshot["energy"],
            snapshot["dominance"],
            snapshot["trust_benevolence"],
            snapshot["trust_competence"],
            snapshot["trust_integrity"],
            snapshot["trust"],
            snapshot["attachment"],
            snapshot["fatigue"],
            snapshot["last_user_interaction"],
            snapshot["interaction_count"],
            snapshot["inferred_valence"],
            snapshot["inferred_arousal"],
                json.dumps(self.current_state.user_mental_model.implied_goals),
                json.dumps(self.current_state.user_mental_model.known_concepts),
                snapshot["baseline_valence"],
                snapshot["baseline_arousal"],
                snapshot["baseline_dominance"],
                snapshot["last_proactive_attempt"],
            )
            try:
                await asyncio.to_thread(self._write_state_row, sqlite_params)
            except Exception as e:
                logger.error(f"Failed to persist state to SQLite: {e}")

        # 3. Publish asynchronous NATS broadcast
        if self.publish_cb:
            state_data = {
                "agent_name": agent_name,
                **snapshot,
                "implied_goals": self.current_state.user_mental_model.implied_goals,
                "known_concepts": self.current_state.user_mental_model.known_concepts,
                "timestamp": time.time(),
            }
            try:
                # Fire and forget publishing. P4-8: spawn_background retains
                # a strong reference so the broadcast cannot be silently
                # cancelled by the garbage collector mid-publish.
                spawn_background(
                    self._background_tasks,
                    self.publish_cb("state.broadcast", state_data),
                )
            except Exception as e:
                logger.warning(f"Failed to trigger NATS state broadcast task: {e}")

        logger.debug(
            f"[State] Persisted to cache (non-blocking Neo4j): V={snapshot['mood']:.2f} Ar={snapshot['energy']:.2f} D={snapshot['dominance']:.2f}"
        )

    def _write_state_row(self, params) -> None:
        """Write the agent_state row. Synchronous; called only via `to_thread`.

        Split out of `persist_state` so the blocking `sqlite3` work happens off
        the event loop -- it ran on every persist, from five call sites
        including the per-turn path, so the loop stalled on a disk write while
        the agent was mid-conversation.

        Opening a connection per call is deliberate rather than lazy: `sqlite3`
        connections are not safe to share across threads by default, so a cached
        one would need its own guard.
        """
        conn = sqlite3.connect(self.db_path)
        try:
            with conn:
                conn.execute(
                    """
                    INSERT INTO agent_state (
                        agent_name, mood, energy, dominance, trust_benevolence, trust_competence,
                        trust_integrity, trust, attachment, fatigue, last_user_interaction,
                        interaction_count, inferred_valence, inferred_arousal, implied_goals,
                        known_concepts, baseline_valence, baseline_arousal, baseline_dominance,
                        last_proactive_attempt, updated_at
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                    ON CONFLICT(agent_name) DO UPDATE SET
                        mood = excluded.mood,
                        energy = excluded.energy,
                        dominance = excluded.dominance,
                        trust_benevolence = excluded.trust_benevolence,
                        trust_competence = excluded.trust_competence,
                        trust_integrity = excluded.trust_integrity,
                        trust = excluded.trust,
                        attachment = excluded.attachment,
                        fatigue = excluded.fatigue,
                        last_user_interaction = excluded.last_user_interaction,
                        interaction_count = excluded.interaction_count,
                        inferred_valence = excluded.inferred_valence,
                        inferred_arousal = excluded.inferred_arousal,
                        implied_goals = excluded.implied_goals,
                        known_concepts = excluded.known_concepts,
                        baseline_valence = excluded.baseline_valence,
                        baseline_arousal = excluded.baseline_arousal,
                        baseline_dominance = excluded.baseline_dominance,
                        last_proactive_attempt = excluded.last_proactive_attempt,
                        updated_at = CURRENT_TIMESTAMP
                """,
                    params,
                )
        finally:
            # `finally`, not a trailing call: the original leaked the connection
            # whenever the INSERT raised.
            conn.close()

    def record_user_interaction(self):
        """Mark that the user just interacted. Called by BrainAgent on every chat.input."""
        self.current_state.last_user_interaction = time.time()

    async def apply_semantic_appraisal(self, new_pad: dict[str, float]):
        """Apply System-2 background semantic-drift results to short-term affect.

        Only the write is serialized under the state lock (A2); the expensive
        LLM inference that produced ``new_pad`` runs upstream, outside the lock.
        """
        async with self._state_lock:
            if "valence" in new_pad and new_pad["valence"] is not None:
                self.current_state.valence = float(new_pad["valence"])
            if "arousal" in new_pad and new_pad["arousal"] is not None:
                self.current_state.arousal = float(new_pad["arousal"])
            if "dominance" in new_pad and new_pad["dominance"] is not None:
                self.current_state.dominance = float(new_pad["dominance"])
            self._enforce_bounds()

    async def update_from_appraisal(self, appraisal, weights: dict[str, float] | None = None):
        """
        PAD + Relational update driven by appraisal vector (§2.3).

        ALMA mood-pull: Each appraisal dimension pulls the corresponding
        PAD dimension toward the appraised value.
        Marsh trust: RI directly modulates trust.
        Bowlby attachment: Trust × interaction frequency.
        """
        G = appraisal.goal_congruence
        RI = appraisal.relationship_impact
        N = appraisal.novelty
        R = appraisal.relevance
        A = appraisal.agency
        NA = appraisal.norm_alignment

        if weights is None:
            weights = {}

        w1 = weights.get("w1_g_to_v", 0.6)
        w2 = weights.get("w2_ri_to_v", 0.4)
        w3 = weights.get("w3_n_to_ar", 0.6)
        w4 = weights.get("w4_r_to_ar", 0.4)
        w5 = weights.get("w5_a_to_d", 0.6)
        w6 = weights.get("w6_na_to_d", 0.4)

        async with self._state_lock:
            # PAD mood-pull (§2.3)
            self.current_state.mood = (
                1 - self.alpha
            ) * self.current_state.mood + self.alpha * (w1 * G + w2 * RI)
            self.current_state.energy = (
                1 - self.beta
            ) * self.current_state.energy + self.beta * (w3 * N + w4 * R)
            self.current_state.dominance = (
                1 - self.gamma
            ) * self.current_state.dominance + self.gamma * (w5 * A + w6 * NA)

            # Relational updates (§2.3)
            self.current_state.trust_benevolence = max(
                0.0, min(1.0, self.current_state.trust_benevolence + self.delta * RI)
            )
            self.current_state.trust_competence = max(
                0.0,
                min(
                    1.0,
                    self.current_state.trust_competence
                    + self.delta * (0.6 * G + 0.4 * R),
                ),
            )
            self.current_state.trust_integrity = max(
                0.0, min(1.0, self.current_state.trust_integrity + self.delta * NA)
            )
            self.current_state.interaction_count += 1
            freq = min(1.0, self.current_state.interaction_count / 100.0)
            self.current_state.attachment = max(
                0.0,
                min(
                    1.0,
                    self.current_state.attachment
                    + self.epsilon * self.current_state.trust * freq,
                ),
            )

            self.current_state.last_update = datetime.now()
            self._enforce_bounds()
        await self.persist_state()

        logger.debug(
            "[State] PAD update: V=%.3f Ar=%.3f D=%.3f T=%.3f At=%.3f",
            self.current_state.mood,
            self.current_state.energy,
            self.current_state.dominance,
            self.current_state.trust,
            self.current_state.attachment,
        )

    async def update_from_event(
        self, event_valence: float, user_trust_delta: float = 0.0
    ):
        """
        Legacy Cognitive Update (backward-compatible).
        Wraps the new appraisal-driven update for code that still uses valence floats.
        """
        now = datetime.now()
        self.current_state.last_user_interaction = time.time()

        # Apply Cognitive Weight (0.7)
        self.current_state.mood = (self.current_state.mood * 0.3) + (
            event_valence * 0.7
        )

        self.current_state.trust = max(
            0.0, min(1.0, self.current_state.trust + user_trust_delta)
        )
        self.current_state.attachment += user_trust_delta * 0.1
        self.current_state.energy -= 0.02

        self.current_state.interaction_count += 1
        self.current_state.last_update = now
        self._enforce_bounds()
        await self.persist_state()

    async def apply_sensory_perception(self, perception_metadata: dict[str, Any]):
        """
        Acoustic Perception Update (confidence-scaled low weight).
        Triggered by emotional/event cues from an acoustic backend.

        Backends that only transcribe (e.g. Whisper) supply no `emotional_bias`.
        That absence means "no acoustic evidence", NOT "the user sounds neutral" —
        see the note below.
        """
        emotion_bias = perception_metadata.get("emotional_bias")
        confidence = perception_metadata.get("confidence", 1.0)
        events = perception_metadata.get("events", []) or []

        if confidence < self.min_perception_confidence and not events:
            logger.debug(
                "[State] Ignored low-confidence acoustic perception: %.2f",
                confidence,
            )
            return

        # A missing emotion estimate must not be defaulted to 0.0 and blended in.
        # Doing so pulls mood and inferred_valence toward zero on *every*
        # perception, erasing affect that semantic appraisal just established —
        # the agent flattens the more the user speaks. An explicit 0.0 from a
        # model that genuinely predicts emotion is a real neutral reading and is
        # still blended; only absence is skipped. bool is excluded because
        # isinstance(True, int) is True.
        has_emotion_estimate = isinstance(emotion_bias, (int, float)) and not isinstance(
            emotion_bias, bool
        )

        async with self._state_lock:
            if has_emotion_estimate:
                # Confidence-scaled emotional bias
                weight = self.sensory_weight * max(0.0, min(1.0, confidence))
                self.current_state.mood = (self.current_state.mood * (1 - weight)) + (
                    emotion_bias * weight
                )

                # Drift user mental model's inferred valence based on acoustic cues
                if confidence >= self.min_perception_confidence:
                    user_weight = self.sensory_weight * max(0.0, min(1.0, confidence))
                    self.current_state.user_mental_model.inferred_valence = (
                        (1 - user_weight)
                        * self.current_state.user_mental_model.inferred_valence
                        + user_weight * emotion_bias
                    )

            # Arousal modulation from acoustic events
            for event in events:
                if event == "Laughter":
                    self.current_state.energy = min(
                        1.0, self.current_state.energy + 0.15
                    )
                    self.current_state.trust = min(1.0, self.current_state.trust + 0.05)
                    logger.info("😄 Agent sensed laughter - Energy/Trust boosted.")
                elif event == "Applause":
                    self.current_state.energy = min(
                        1.0, self.current_state.energy + 0.2
                    )
                    logger.info("👏 Agent sensed applause - Energy spike.")
                elif event in ["Cough", "Sneeze"]:
                    self.current_state.attachment = min(
                        1.0, self.current_state.attachment + 0.02
                    )
                    logger.debug(
                        f"🤧 Agent sensed {event} - Attachment nudged (Empathy)."
                    )

            self._enforce_bounds()
        await self._persist_sensory_state_if_due()

    async def apply_somatic_perception(self, somatic: dict[str, Any]):
        """Visual Somatic Homeostasis — recognising a comfort object feels good.

        The visual counterpart to `apply_sensory_perception` above: that folds
        *how the user sounds* into mood, this folds *what the agent is looking
        at* into valence and arousal. Together they are the two halves of the
        perception-to-affect path.

        Roadmap §C (`docs/cvs4_architecture_roadmap.md`) specifies a dopamine
        spike alongside the valence one, and both now happen literally: the
        valence lift below, and a real phasic burst via `release_dopamine`.
        Before phasic dopamine existed, the burst could only be approximated by
        moving mood and letting the derived term follow, which meant the reward
        vanished the instant valence drifted back.

        Absence of a match must never reach this method as a zero spike. Doing
        so would drag mood toward neutral on every appraisal interval and
        flatten the agent the longer it looks at nothing in particular -- the
        same failure mode documented for a missing acoustic emotion estimate.
        """
        if not somatic:
            return

        valence_spike = somatic.get("valence_spike", 0.0)
        arousal_spike = somatic.get("arousal_spike", 0.0)
        try:
            valence_spike = float(valence_spike)
            arousal_spike = float(arousal_spike)
        except (TypeError, ValueError):
            logger.warning(
                "[State] Ignoring somatic perception with non-numeric spikes: %r",
                somatic,
            )
            return

        if valence_spike <= 0.0 and arousal_spike <= 0.0:
            return

        # Roadmap §C: D_t = min(1.0, D_{t-1} + 0.25). Falls back to the valence
        # lift alone when a caller supplies no explicit burst.
        dopamine_spike = somatic.get("dopamine_spike", SOMATIC_DOPAMINE_SPIKE)
        try:
            dopamine_spike = float(dopamine_spike)
        except (TypeError, ValueError):
            dopamine_spike = SOMATIC_DOPAMINE_SPIKE

        entities = somatic.get("entities") or []
        async with self._state_lock:
            before_valence = self.current_state.valence
            self.current_state.valence = min(
                1.0, self.current_state.valence + valence_spike
            )
            self.current_state.arousal = min(
                1.0, self.current_state.arousal + arousal_spike
            )
            self._enforce_bounds()
            # After bounds, so the burst is measured against the settled tonic.
            self.current_state.release_dopamine(dopamine_spike)
            after_valence = self.current_state.valence

        logger.info(
            "👁️  Somatic comfort recognised %s — valence %.2f → %.2f (dopamine now %.2f).",
            entities,
            before_valence,
            after_valence,
            self.current_state.dopamine,
        )
        await self._persist_sensory_state_if_due()

    async def release_cortisol(self, amount: float, *, reason: str = "") -> float:
        """Fire an acute stress response under the state lock.

        `AgentState.release_cortisol` is the primitive and does no locking. A
        fire-and-forget System-2 appraisal writes affect concurrently with the
        synchronous path (finding A2), and the burst peak is computed *relative
        to the tonic floor* — so an unlocked release that interleaves with a
        valence write can measure its peak against a floor that no longer
        exists and store a burst of the wrong size.

        This is the API stress channels should call. The dopamine equivalent
        below exists for the same reason.
        """
        async with self._state_lock:
            level = self.current_state.release_cortisol(amount)
        if reason:
            logger.info(
                "[Endocrine] Cortisol released (%s) — now %.2f.", reason, level
            )
        return level

    async def release_dopamine(self, amount: float, *, reason: str = "") -> float:
        """Fire a reward burst under the state lock. See `release_cortisol`.

        `apply_somatic_perception` does not call this: it is already inside the
        lock and holds it across the valence lift and the burst deliberately,
        so the peak is measured against the settled tonic. Re-entering here
        would deadlock on a non-reentrant `asyncio.Lock`.
        """
        async with self._state_lock:
            level = self.current_state.release_dopamine(amount)
        if reason:
            logger.info(
                "[Endocrine] Dopamine released (%s) — now %.2f.", reason, level
            )
        return level

    async def handle_system_tick(self, tick_metadata: dict[str, Any]):
        """
        Idle evolution triggered by NATS system.tick.
        Implements ALMA exponential decay (§2.2) and Fatigue updates.

        audit/ROADMAP.md P2-14 (M2-A1): this ran **outside `_state_lock`**,
        mutating fatigue, mood, energy, dominance and all three trust fields
        while every other mutation path in this class held it -- including
        `release_cortisol` and `release_dopamine` directly above, whose
        docstrings spell out why affect mutation must be serialized. That is
        the audit's own stated root cause for this finding: the lock discipline
        is careful everywhere it was thought about, and the tick path was not
        thought about.

        Concretely, the tick arrives on a NATS callback while a fire-and-forget
        System-2 appraisal can be writing affect (finding A2), so an unlocked
        decay could read `mood` before that write and store its result after,
        discarding it. The endocrine layer makes it worse rather than merely
        racy: burst peaks are measured relative to the tonic floor, and the
        tonic floor is a pure function of the valence and arousal this method
        rewrites -- so a release interleaving with an unlocked decay measures
        its peak against a floor that never existed.

        `persist_state` is called from inside the lock deliberately. It
        serializes on `_persist_lock`, which is **not** `_state_lock` precisely
        because callers reach it already holding the state lock (see its own
        docstring); `asyncio.Lock` is not reentrant, so the separation is what
        makes this safe. `_enforce_bounds` and `_update_fatigue_python` are
        synchronous and take no lock.
        """
        now = tick_metadata.get("timestamp", time.time())
        dt_hours = tick_metadata.get("interval", 60) / 3600.0

        async with self._state_lock:
            # Evolve fatigue
            hour = datetime.fromtimestamp(now).hour
            is_night = hour >= 22 or hour < 6
            try:
                import cognitive_rust

                rust_state = cognitive_rust.FatigueState(
                    self.current_state.fatigue,
                    self.current_state.last_user_interaction,
                )
                updated_rust = cognitive_rust.update_fatigue(
                    rust_state, now, dt_hours, is_night
                )
                self.current_state.fatigue = updated_rust.fatigue
            except ImportError:
                self._update_fatigue_python(now, dt_hours, is_night)
            except Exception:
                logger.exception(
                    "[State] Unexpected Rust fatigue update error; using Python fallback."
                )
                self._update_fatigue_python(now, dt_hours, is_night)

            # ALMA Decay (§2.2): short-term affect decays back to baseline
            base_v = self.current_state.baseline_valence
            base_ar = self.current_state.baseline_arousal
            base_d = self.current_state.baseline_dominance

            self.current_state.mood = base_v + (
                self.current_state.mood - base_v
            ) * math.exp(-self.lambda_decay * dt_hours)
            self.current_state.energy = base_ar + (
                self.current_state.energy - base_ar
            ) * math.exp(-self.lambda_decay * dt_hours)
            self.current_state.dominance = base_d + (
                self.current_state.dominance - base_d
            ) * math.exp(-self.lambda_decay * dt_hours)

            tb_drift = (
                self.trust_baseline - self.current_state.trust_benevolence
            ) * 0.01
            tc_drift = (
                self.trust_baseline - self.current_state.trust_competence
            ) * 0.01
            ti_drift = (
                self.trust_baseline - self.current_state.trust_integrity
            ) * 0.01
            self.current_state.trust_benevolence += tb_drift
            self.current_state.trust_competence += tc_drift
            self.current_state.trust_integrity += ti_drift

            self.current_state.last_update = datetime.fromtimestamp(now)
            self._enforce_bounds()
            await self.persist_state()
        logger.debug(
            "[State Heartbeat] V=%.3f Ar=%.3f D=%.3f F=%.3f",
            self.current_state.mood,
            self.current_state.energy,
            self.current_state.dominance,
            self.current_state.fatigue,
        )

    def check_proactive_eligibility(self) -> bool:
        """
        Phase 1: Proactive Engagement.
        Evaluates whether the agent should spontaneously initiate contact.
        """
        if not getattr(Config, "PROACTIVE_ENABLED", False):
            return False

        now = time.time()

        debug_override = getattr(Config, "PROACTIVE_DEBUG_THRESHOLD_OVERRIDE", None)
        if debug_override is not None:
            try:
                threshold = float(debug_override)
            except (TypeError, ValueError):
                threshold = Config.PROACTIVE_IDLE_THRESHOLD_SECONDS
        else:
            threshold = Config.PROACTIVE_IDLE_THRESHOLD_SECONDS

        idle_duration = now - self.current_state.last_user_interaction
        if idle_duration < threshold:
            return False

        cooldown = getattr(Config, "PROACTIVE_COOLDOWN_SECONDS", 3600)
        if (now - self.current_state.last_proactive_attempt) < cooldown:
            return False

        min_energy = getattr(Config, "PROACTIVE_MIN_ENERGY", 0.2)
        if self.current_state.energy < min_energy:
            logger.debug(
                "[State] Proactive SKIPPED: energy %.2f < min %.2f",
                self.current_state.energy,
                min_energy,
            )
            return False

        # Roadmap leftovers Item 4b (M3-D2): turn_taking_probability was
        # computed by calculate_pacing_parameters and read by no caller.
        # "Turn taking" -- deciding to take the conversational floor -- is
        # what proactive speech literally is, so this is where it belongs,
        # NOT scaling the pacing sleep above: silence_duration_ms and
        # turn_taking_probability are both driven by the same dominance and
        # fatigue terms, so applying the probability there would apply D and
        # F twice. No other gate here reads dominance or valence, so this
        # does not double-count anything. Verified before wiring
        # (tools/measure/m4b_turn_taking_gate.py): at the default 0.5
        # threshold the gate blocks 16.9% of the (valence, dominance,
        # fatigue) states the persona schema and live-state clamp actually
        # permit -- inside the plan's [15%, 50%] "meaningful minority" pass
        # band, so this is a real discriminator, not decoration.
        turn_probability = (
            0.5
            + 0.3 * self.current_state.dominance
            - 0.1 * self.current_state.fatigue
            + 0.2 * self.current_state.valence
        )
        min_turn_probability = getattr(
            Config, "PROACTIVE_MIN_TURN_PROBABILITY", 0.5
        )
        if turn_probability < min_turn_probability:
            logger.debug(
                "[State] Proactive SKIPPED: turn_taking_probability %.2f < min %.2f",
                turn_probability,
                min_turn_probability,
            )
            return False

        logger.info(
            "[State] Proactive ELIGIBLE: idle=%.0fs threshold=%.0fs energy=%.2f "
            "turn_taking_probability=%.2f",
            idle_duration,
            threshold,
            self.current_state.energy,
            turn_probability,
        )
        return True

    def mark_proactive_attempt(self):
        """Record that a proactive generation was initiated.

        Now on `current_state` (see the field's own comment on why), so it
        persists across a restart and reaches the sibling process's
        `StateService` via the same `state.broadcast` every other affect
        field already rides -- previously a plain instance attribute that
        neither survived a restart nor ever crossed the process boundary.
        """
        self.current_state.last_proactive_attempt = time.time()

    def _enforce_bounds(self):
        self.current_state.mood = max(-1.0, min(1.0, self.current_state.mood))
        self.current_state.energy = max(0.0, min(1.0, self.current_state.energy))
        self.current_state.dominance = max(0.0, min(1.0, self.current_state.dominance))
        self.current_state.trust_benevolence = max(
            0.0, min(1.0, self.current_state.trust_benevolence)
        )
        self.current_state.trust_competence = max(
            0.0, min(1.0, self.current_state.trust_competence)
        )
        self.current_state.trust_integrity = max(
            0.0, min(1.0, self.current_state.trust_integrity)
        )
        self.current_state.attachment = max(
            0.0, min(1.0, self.current_state.attachment)
        )
        self.current_state.fatigue = max(0.0, min(1.0, self.current_state.fatigue))
        self.current_state.user_mental_model.inferred_valence = max(
            -1.0, min(1.0, self.current_state.user_mental_model.inferred_valence)
        )
        self.current_state.user_mental_model.inferred_arousal = max(
            0.0, min(1.0, self.current_state.user_mental_model.inferred_arousal)
        )

    async def update_theory_of_mind(
        self, user_input: str, tom_inferences: dict[str, Any] | None = None
    ):
        """
        Updates the Theory of Mind mental model of the user.
        Runs a zero-overhead text concepts tracker and digests LLM-inferred parameters.
        """
        from ..cognitive.tom import update_known_concepts

        # 1. Update vocabulary tracker (zero LLM overhead text indexing)
        self.current_state.user_mental_model.known_concepts = update_known_concepts(
            self.current_state.user_mental_model.known_concepts, user_input
        )

        # 2. Update LLM-inferred fields if available
        if tom_inferences:
            if "inferred_valence" in tom_inferences:
                try:
                    self.current_state.user_mental_model.inferred_valence = float(
                        tom_inferences["inferred_valence"]
                    )
                except (ValueError, TypeError) as e:
                    logger.warning(
                        "[ToM] Failed to parse inferred_valence: %s (value: %s)",
                        e,
                        tom_inferences["inferred_valence"],
                    )
            if "inferred_arousal" in tom_inferences:
                try:
                    self.current_state.user_mental_model.inferred_arousal = float(
                        tom_inferences["inferred_arousal"]
                    )
                except (ValueError, TypeError) as e:
                    logger.warning(
                        "[ToM] Failed to parse inferred_arousal: %s (value: %s)",
                        e,
                        tom_inferences["inferred_arousal"],
                    )
            if "implied_goals" in tom_inferences:
                implied_goals_raw = tom_inferences["implied_goals"]
                if isinstance(implied_goals_raw, list):
                    self.current_state.user_mental_model.implied_goals = (
                        implied_goals_raw
                    )
                else:
                    self.current_state.user_mental_model.implied_goals = []
                    logger.warning(
                        f"[StateService] Unexpected type for implied_goals in tom_inferences: {type(implied_goals_raw)}. Falling back to empty list."
                    )

        self._enforce_bounds()
        await self.persist_state()

    def get_context_snapshot(self) -> dict[str, Any]:
        return {
            "emotion": self.get_emotion_label(),
            "mood": self.current_state.mood,
            "energy": self.current_state.energy,
            "dominance": self.current_state.dominance,
            "trust": self.current_state.trust,
            "trust_benevolence": self.current_state.trust_benevolence,
            "trust_competence": self.current_state.trust_competence,
            "trust_integrity": self.current_state.trust_integrity,
            "attachment": self.current_state.attachment,
            "interaction_count": self.current_state.interaction_count,
            "active_goals": self.current_state.active_goals,
            # PAD aliases for new consumers
            "valence": self.current_state.mood,
            "arousal": self.current_state.arousal,
            "fatigue": self.current_state.fatigue,
            # Endocrine hormones (Tier-5)
            "cortisol": self.current_state.cortisol,
            "dopamine": self.current_state.dopamine,
            # Theory of Mind snapshot — dict format
            "user_mental_model": self.current_state.user_mental_model.model_dump(),
        }

    def get_behavioral_directive(self) -> str:
        """Translates internal state into a natural language directive for the LLM."""
        V = self.current_state.mood
        Ar = self.current_state.energy
        D = self.current_state.dominance
        T = self.current_state.trust

        if V < -0.6:
            direct = "You are feeling deeply melancholic and reserved."
        elif V > 0.6:
            direct = "You are in a vibrant, optimistic state."
        else:
            direct = "You are grounded and emotionally stable."

        if Ar < 0.3:
            direct += " Your energy is low; keep replies brief and pacing slow."
        elif Ar > 0.8:
            direct += " You are high-energy; use expressive, dynamic language."

        if D < 0.3:
            direct += " You feel uncertain and deferential — ask more, assert less."
        elif D > 0.7:
            direct += " You feel confident and in control — speak with conviction."

        if T < 0.3:
            direct += " You are feeling skeptical and maintaining boundaries."
        elif T > 0.8:
            direct += " You feel a deep, familiar bond with the user."

        return direct

    def get_emotion_label(self) -> str:
        V = self.current_state.mood
        Ar = self.current_state.energy
        D = self.current_state.dominance

        if V > 0.4 and Ar > 0.6:
            return "excited"
        if V > 0.4:
            return "happy"
        if V < -0.4 and Ar > 0.6:
            return "angry"
        if V < -0.4:
            return "sad"
        if Ar > 0.8:
            return "alert"
        if D < 0.3:
            return "uncertain"
        return "neutral"

    async def _persist_sensory_state_if_due(self):
        now = time.time()
        if now - self._last_sensory_persist < self.sensory_persist_interval:
            return
        self._last_sensory_persist = now
        await self.persist_state()

    def _update_fatigue_python(self, now: float, dt_hours: float, is_night: bool):
        """Fallback fatigue update matching Rust behavior."""
        circadian_multiplier = 1.8 if is_night else 1.0
        idle_duration = now - self.current_state.last_user_interaction
        is_idle = idle_duration > 300.0
        k_drain = 0.15
        k_restore = 0.20
        if is_idle:
            next_fatigue = self.current_state.fatigue - (
                k_restore * dt_hours / circadian_multiplier
            )
        else:
            next_fatigue = self.current_state.fatigue + (
                k_drain * dt_hours * circadian_multiplier
            )
        self.current_state.fatigue = max(0.0, min(1.0, next_fatigue))
