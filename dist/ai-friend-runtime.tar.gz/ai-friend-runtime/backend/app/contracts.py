"""
NATS Mesh Message Contracts — CVS-3.5

Typed Pydantic models for every inter-agent message on the NATS bus.
Using these at publish/subscribe boundaries catches key-rename and
type-mismatch bugs at runtime instead of silently dropping data.

Usage:
    # Publishing
    msg = ChatInput(text="hello", utterance_id="utt-1")
    await agent.publish("chat.input", msg.model_dump())

    # Receiving
    msg = ChatInput.model_validate(data)
"""

from __future__ import annotations

import time
from enum import Enum
from typing import Any, ClassVar

from pydantic import BaseModel, Field, field_validator


class Topics(str, Enum):
    CHAT_INPUT = "chat.input"
    CHAT_OUTPUT = "chat.output"
    VISION_CONTROL = "vision.control"
    VISION_FRAMES = "vision.frames"
    VISION_DESCRIPTION = "vision.description"
    AUDIO_PERCEPTION = "audio.perception"
    AUDIO_STOP = "audio.stop"
    AUDIO_RESUME = "audio.resume"
    AUDIO_INBOUND = "audio.inbound"
    AUDIO_STREAM = "audio.stream"
    VOICE_WARM = "voice.warm"
    VOICE_SEGMENTATION_FEEDBACK = "voice.segmentation_feedback"
    SYSTEM_TICK = "system.tick"
    MEMORY_SURFACED = "memory.surfaced"
    STATE_UPDATE = "state.update"
    STATE_SUBCONSCIOUS = "state.subconscious"
    USER_VOICE_PROPERTIES = "user.voice.properties"
    AGENT_VOICE_MODULATION = "agent.voice.modulation"
    AUDIO_PLAYBACK_VISEMES = "audio.playback.visemes"
    AUDIO_PLAYBACK_PROGRESS = "audio.playback.progress"
    AMBIENT_NOISE_TELEMETRY = "ambient.noise.telemetry"
    # "state.presence", not "session.presence": AI_MESSAGES' JetStream
    # subject pattern is state.>, and a subject outside every declared
    # pattern needs a check_subject_wiring.py allowlist entry to justify why
    # (see ambient.noise.telemetry's) -- fitting the existing wildcard needs
    # no such justification, and "who is connected" is state as much as
    # state.broadcast's affect snapshot is.
    SESSION_PRESENCE = "state.presence"


# ─── chat.input ──────────────────────────────────────────────
class ChatInputMetadata(BaseModel):
    model_config = {"extra": "allow"}

    source: str = "whisper"
    confidence: float = 0.9
    utterance_id: str | None = None


class ChatInput(BaseModel):
    """Published by STTAgent on `chat.input` after final transcription."""

    model_config = {"extra": "allow"}

    text: str
    utterance_id: str | None = None
    turn_id: str | None = None
    metadata: ChatInputMetadata = Field(default_factory=ChatInputMetadata)
    latency_metadata: dict[str, Any] | None = None


# ─── chat.output ─────────────────────────────────────────────
class ChatOutputAffect(BaseModel):
    """PAD and Relational affect vector attached to each speech chunk."""

    valence: float = 0.0
    arousal: float = 0.5
    dominance: float = 0.5
    trust: float = 0.5
    attachment: float = 0.1
    emotion: str = "neutral"
    fatigue: float = 0.0
    user_distance: float | None = None


class ChatOutput(BaseModel):
    """Published by BrainAgent on `chat.output` for each speech chunk or done signal."""

    model_config = {"extra": "allow"}

    content: str | None = None
    done: bool = False
    turn_id: str | None = None
    affect: ChatOutputAffect | None = None

    # The deprecated prosody block (confidence, intensity, speaking_rate,
    # pause_bias, paralinguistic_tags) was removed here. Prosody has a single
    # source: the voice agent derives it from `affect` above via
    # `contracts::vad_to_prosody` (Rust). Python used to populate these with a
    # formula that disagreed with the Rust one, and nothing ever read them.
    #
    # Safe to remove in both rollout directions, which is why they went rather
    # than staying deprecated forever: this model is `extra: "allow"`, so a
    # message from an older producer still carrying them validates; and the
    # Rust struct sets `#[serde(default)]` on every field with no
    # `deny_unknown_fields`, so a new message missing them deserializes there
    # too. No deploy ordering is required.

    # Metadata
    timestamp: float = Field(default_factory=time.time)
    full_response: str | None = None
    generation_error: str | None = None
    proactive: bool = False
    metadata: dict[str, Any] | None = None
    latency_metadata: dict[str, Any] | None = None


# ─── audio.perception ────────────────────────────────────────
class SpeculativeIntent(BaseModel):
    name: str = "SPECULATIVE_STOP"
    keywords: list[str] = Field(default_factory=list)
    confidence: float = 0.0
    text: str = ""
    timestamp: float = 0.0
    utterance_id: str | None = None


class AudioPerception(BaseModel):
    """Published by STTAgent on `audio.perception` from the SenseVoice fast path."""

    text: str = ""
    intent: str | None = None
    intent_type: str = "CONVERSATIONAL"  # COMMAND, PERCEPTION, CONVERSATIONAL
    keywords: list[str] = Field(default_factory=list)
    confidence: float = 0.0
    snr: float = 0.0  # Signal-to-Noise Ratio
    paralinguistic_events: list[str] = Field(
        default_factory=list
    )  # [laughter], [cough], etc.
    speculative_intent: SpeculativeIntent | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)
    timestamp: float = 0.0
    utterance_id: str | None = None


# ─── audio.stop / audio.resume ───────────────────────────────
class AudioStop(BaseModel):
    """Published on `audio.stop` to halt voice playback."""

    interrupt: bool = True
    speculative: bool = False
    reason: str | None = None
    command_text: str | None = None
    intent: str | None = None
    intent_type: str = (
        "VOICE_INTERRUPTION"  # VOICE_INTERRUPTION, VISION_INTERRUPTION, SYSTEM_HALT
    )
    keywords: list[str] = Field(default_factory=list)
    confidence: float = 0.0
    perception_text: str | None = None
    utterance_id: str | None = None
    turn_id: str | None = None


class AudioResume(BaseModel):
    """Published on `audio.resume` to resume voice playback after rejected stop."""

    reason: str = "conflict_rejected"
    perception_text: str | None = None
    utterance_id: str | None = None


# ─── memory.surfaced ─────────────────────────────────────────
class MemoryScope(BaseModel):
    """Hierarchical scope for memory items (Wings -> Rooms -> Drawers)."""

    wing: str = "personal"
    room: str | None = None
    drawer_id: str | None = None


class SurfacedMemory(BaseModel):
    content: str
    raw_content: str  # Verbatim Truth
    scope: MemoryScope = Field(default_factory=MemoryScope)
    score: float = 0.0
    valence: float = 0.0
    created_at: str | None = None
    recall_count: int = 0
    metadata: dict[str, Any] = Field(default_factory=dict)


class MemorySurfaced(BaseModel):
    """Published by SurfacingAgent on `memory.surfaced`."""

    memories: list[SurfacedMemory] = Field(default_factory=list)
    source: str = "episodic"
    provenance: str = "pgvector_actr"  # cognitive source of the memory
    context: str | None = None


# ─── vision.description ──────────────────────────────────────
class VisionDescription(BaseModel):
    """Published by VisionAgent on `vision.description` after VLM appraisal."""

    description: str
    source: str = "screen"
    timestamp: float = Field(default_factory=time.time)
    # Estimated distance in metres via a calibrated pinhole-camera formula
    # (see Config.VISION_FOCAL_PX / _calculate_user_distance in
    # vision/agent.py); falls back to 1.0 when no face is detected or
    # calibration inputs are unavailable.
    user_distance: float | None = None
    # P3-1: whether this frame cleared VisualAppraisalService's own
    # habituation delta (reused, not recomputed) rather than being a cached
    # repeat. Downstream salience gating for visual episodic memory
    # (SubconsciousAgent) uses this so a static scene doesn't mint a new
    # memory every VLM_APPRAISAL_INTERVAL. Defaults True so a producer that
    # predates this field (or genuinely can't tell) does not silently
    # suppress storage.
    is_novel: bool = True


# ─── state.update ────────────────────────────────────────────
class StateUpdate(BaseModel):
    """The affect broadcast published on `state.update` when agent state changes.

    This is the single definition of that payload. `CognitivePipeline` builds it
    with `from_snapshot` at its two publish sites, and `SurfacingAgent` reads the
    same fields off the wire to drive mood-congruent recall and APRA vocal
    modulation. The subject also carries a separate lifecycle message from
    `BaseAgent.set_state` (`{agent, state, timestamp}` — "thinking"/"idle"); that
    one is deliberately *not* modelled here, and the consumer tolerates it because
    it reads affect fields with defaults rather than validating a fixed shape.

    Before this was wired up the payload lived as an 11-field dict literal
    duplicated across both pipeline sites, and this model shadowed it unused —
    two definitions of one wire contract, free to drift apart silently.
    """

    model_config = {"extra": "allow"}

    mood: float = 0.0
    energy: float = 0.5
    dominance: float = 0.5
    trust: float = 0.5
    attachment: float = 0.1
    emotion: str = "neutral"
    interaction_count: int = 0
    cortisol: float = 0.0
    dopamine: float = 0.0
    fatigue: float = 0.0
    user_mental_model: dict[str, Any] | None = None

    @classmethod
    def from_snapshot(cls, snapshot: dict[str, Any]) -> StateUpdate:
        """Build the broadcast from a `StateService.get_context_snapshot()` dict.

        Only the modelled fields are pulled; a key the snapshot omits falls back
        to this model's default, so the defaults live here and nowhere else.
        Snapshot keys outside the schema (`valence`, `arousal`, …) are dropped,
        exactly as the previous hand-written literal dropped them.
        """
        return cls(**{k: snapshot[k] for k in cls.model_fields if k in snapshot})


# ─── user.voice.properties ───────────────────────────────────
class UserVoiceProperties(BaseModel):
    model_config = {"extra": "allow"}

    pitch_f0: float
    energy_rms: float
    # docs/FUTURE_WORK.md §1.2: None until the first utterance completes and
    # a real words-over-duration rate exists -- see the Rust struct's own
    # comment (crates/contracts/src/lib.rs) for why this changed on both
    # sides of the wire together rather than just here.
    tempo_wpm: float | None = None
    timestamp: float = Field(default_factory=time.time)


# ─── agent.voice.modulation ───────────────────────────────────
class ProsodyFrame(BaseModel):
    model_config = {"extra": "allow"}

    time_offset_ms: int = Field(..., ge=0)
    rate: float
    pitch: float
    volume: float


class AgentVoiceModulation(BaseModel):
    model_config = {"extra": "allow"}

    # A7: the reference generator (generate_apra_trajectory, cognitive-rust)
    # steps in exactly 50ms increments, but the contract only needs frames close
    # enough together for smooth playback - not that exact grid. A hard "==50"
    # check made any jitter or resampling (e.g. a future non-Rust producer, or a
    # frame dropped/merged in transit) reject the *entire* trajectory.
    MAX_FRAME_GAP_MS: ClassVar[int] = 250

    trajectory: list[ProsodyFrame] = Field(..., min_length=1)
    timestamp: float = Field(default_factory=time.time)

    @field_validator("trajectory")
    @classmethod
    def validate_trajectory(cls, v: list[ProsodyFrame]) -> list[ProsodyFrame]:
        if not v:
            raise ValueError("Trajectory must not be empty.")
        if v[0].time_offset_ms < 0:
            raise ValueError("First offset must be >= 0.")
        for i in range(1, len(v)):
            gap = v[i].time_offset_ms - v[i - 1].time_offset_ms
            if gap <= 0:
                raise ValueError(
                    "Trajectory must be strictly ordered by time_offset_ms ascending."
                )
            if gap > AgentVoiceModulation.MAX_FRAME_GAP_MS:
                raise ValueError(
                    "Consecutive frames must be no more than "
                    f"{AgentVoiceModulation.MAX_FRAME_GAP_MS} ms apart "
                    f"(got {gap} ms)."
                )
        return v


# ─── audio.playback.visemes ───────────────────────────────────
class PlaybackVisemes(BaseModel):
    model_config = {"extra": "allow"}

    target_level: float
    viseme_id: str
    timestamp: float = Field(default_factory=time.time)


# ─── audio.playback.progress ───────────────────────────────────
class AudioPlaybackProgress(BaseModel):
    model_config = {"extra": "allow"}

    utterance_id: str
    character_offset: int = Field(..., ge=0)
    word_index: int = Field(..., ge=0)
    completed: bool
    timestamp: float = Field(default_factory=time.time)


# ─── ambient.noise.telemetry ───────────────────────────────────
class AmbientNoiseTelemetry(BaseModel):
    model_config = {"extra": "allow"}

    rms_energy: float
    noise_floor_db: float
    timestamp: float = Field(default_factory=time.time)


# ─── session.presence ───────────────────────────────────────
class SessionPresence(BaseModel):
    """Published by `transport_agent` on every LiveKit room join/leave edge
    (Phase 3.1) -- the only component with direct visibility into who is
    actually connected. `subconscious_agent` runs as a separate process and
    has no other way to know: without this, a proactive thought generated
    while nobody was listening had nowhere to go but a synthesized-and-
    discarded utterance (see `app/state/proactive_queue.py`)."""

    model_config = {"extra": "allow"}

    connected: bool
    participant_count: int = 0
    timestamp: float = Field(default_factory=time.time)
