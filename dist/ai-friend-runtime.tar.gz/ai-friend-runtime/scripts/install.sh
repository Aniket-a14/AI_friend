#!/bin/bash
# ==============================================================================
#  AI Friend — Automated Multi-Platform Installer (macOS & Linux)
#  Usage:
#    curl -fsSL https://raw.githubusercontent.com/Aniket-a14/AI_friend/main/scripts/install.sh | bash
# ==============================================================================
set -euo pipefail

# ── Styling & Colors ──────────────────────────────────────────────────────────
BOLD='\033[1m'
DIM='\033[2m'
GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

log_info() { echo -e "${CYAN}==>${NC} ${BOLD}$1${NC}"; }
log_success() { echo -e "${GREEN}✓${NC} $1"; }
log_warn() { echo -e "${YELLOW}⚠ $1${NC}"; }
log_error() { echo -e "${RED}✗ ERROR: $1${NC}" >&2; }

# ── Banner ───────────────────────────────────────────────────────────────────
echo -e "${BOLD}"
echo "      _    ___   _____ ____  ___ _____ _   _ ____  "
echo "     / \  |_ _| |  ___|  _ \|_ _| ____| \ | |  _ \ "
echo "    / _ \  | |  | |_  | |_) || ||  _| |  \| | | | |"
echo "   / ___ \ | |  |  _| |  _ < | || |___| |\  | |_| |"
echo "  /_/   \_\___| |_|   |_| \_\___|_____|_| \_|____/ "
echo -e "${NC}"
echo -e "${DIM}  An embodied, local-first lifelong companion on your own hardware.${NC}\n"

# ── Parse Arguments ──────────────────────────────────────────────────────────
TARGET_DIR="${HOME}/AI_friend"
AUTO_START=true
DRY_RUN=false

while [[ $# -gt 0 ]]; do
  case "$1" in
    --dir)
      TARGET_DIR="$2"
      shift 2
      ;;
    --no-start)
      AUTO_START=false
      shift
      ;;
    --dry-run)
      DRY_RUN=true
      shift
      ;;
    --help|-h)
      echo "Usage: install.sh [--dir <path>] [--no-start] [--dry-run]"
      echo "  --dir <path>  Target installation directory (default: ~/AI_friend)"
      echo "  --no-start    Install and configure without starting the mesh"
      echo "  --dry-run     Check system requirements without making modifications"
      exit 0
      ;;
    *)
      shift
      ;;
  esac
done

# ── Platform Detection ───────────────────────────────────────────────────────
OS="$(uname -s)"
ARCH="$(uname -m)"
log_info "Detected Platform: ${OS} (${ARCH})"

case "${OS}" in
  Darwin)
    PLATFORM_NAME="macOS"
    if [[ "${ARCH}" == "arm64" ]]; then
      HW_ACCEL="Apple Silicon Metal & Neural Engine"
    else
      HW_ACCEL="Intel x86_64"
    fi
    ;;
  Linux)
    PLATFORM_NAME="Linux"
    if command -v nvidia-smi >/dev/null 2>&1; then
      HW_ACCEL="NVIDIA CUDA Acceleration"
    else
      HW_ACCEL="Standard CPU (AVX-512 / OpenVINO)"
    fi
    ;;
  *)
    log_error "Unsupported operating system: ${OS}. Please use install.ps1 on Windows."
    exit 1
    ;;
esac

log_success "Platform target: ${PLATFORM_NAME} (${HW_ACCEL})"

# ── Prerequisite Validation ──────────────────────────────────────────────────
log_info "Verifying core system prerequisites..."

# 1. Check Git
if ! command -v git >/dev/null 2>&1; then
  log_warn "Git is not installed."
  if [[ "${OS}" == "Darwin" ]]; then
    echo "Installing Xcode Command Line Tools..."
    xcode-select --install || true
  elif command -v apt-get >/dev/null 2>&1; then
    sudo apt-get update && sudo apt-get install -y git
  elif command -v dnf >/dev/null 2>&1; then
    sudo dnf install -y git
  elif command -v pacman >/dev/null 2>&1; then
    sudo pacman -Sy --noconfirm git
  else
    log_error "Please install Git and re-run this script."
    exit 1
  fi
fi
log_success "Git is available ($(git --version))"

# 2. Check Python 3.11+
PYTHON_CMD=""
for cmd in python3.13 python3.12 python3.11 python3 python; do
  if command -v "$cmd" >/dev/null 2>&1; then
    VERSION=$("$cmd" -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")' 2>/dev/null || echo "0.0")
    MAJOR=$("$cmd" -c 'import sys; print(sys.version_info.major)' 2>/dev/null || echo "0")
    MINOR=$("$cmd" -c 'import sys; print(sys.version_info.minor)' 2>/dev/null || echo "0")
    if [[ "$MAJOR" -ge 3 ]] && [[ "$MINOR" -ge 11 ]]; then
      PYTHON_CMD="$cmd"
      break
    fi
  fi
done

if [[ -z "$PYTHON_CMD" ]]; then
  log_warn "Python 3.11+ is required."
  if [[ "${OS}" == "Darwin" ]] && command -v brew >/dev/null 2>&1; then
    echo "Installing Python via Homebrew..."
    brew install python@3.12
    PYTHON_CMD="python3.12"
  else
    log_error "Please install Python 3.11 or newer (https://www.python.org/downloads/)."
    exit 1
  fi
fi
log_success "Python 3.11+ available (${PYTHON_CMD})"

# 3. Check Docker
if ! command -v docker >/dev/null 2>&1; then
  log_warn "Docker is not installed."
  echo "Docker Desktop is required to run the 9-agent container mesh."
  echo "Please download and install Docker from: https://www.docker.com/products/docker-desktop"
  if [[ "$DRY_RUN" == true ]]; then
    exit 0
  fi
fi

# 4. Check Ollama
if ! command -v ollama >/dev/null 2>&1; then
  log_warn "Ollama is not installed in PATH."
  echo "Ollama is used for 100% local LLM inference (Llama 3.2 3B & Nomic Embeddings)."
  echo "You can install Ollama via: curl -fsSL https://ollama.com/install.sh | sh"
fi

if [[ "$DRY_RUN" == true ]]; then
  log_success "Dry run checks complete! System is compatible."
  exit 0
fi

# ── Clone or Update Repository ───────────────────────────────────────────────
REPO_URL="https://github.com/Aniket-a14/AI_friend.git"

if [[ -d "$TARGET_DIR/.git" ]]; then
  log_info "Existing repository found at ${TARGET_DIR}. Pulling latest changes..."
  cd "$TARGET_DIR"
  git pull --ff-only || log_warn "Could not fast-forward git repo; using local checkout."
else
  log_info "Cloning AI Friend repository to ${TARGET_DIR}..."
  mkdir -p "$(dirname "$TARGET_DIR")"
  git clone "$REPO_URL" "$TARGET_DIR"
  cd "$TARGET_DIR"
fi

# ── Environment & Config Setup ───────────────────────────────────────────────
log_info "Configuring environment..."

if [[ ! -f .env ]]; then
  cp .env.example .env
  log_success "Created .env from .env.example"
fi

# Setup Python Virtual Environment
if [[ ! -d .venv ]]; then
  log_info "Creating Python virtual environment..."
  "$PYTHON_CMD" -m venv .venv
  log_success "Virtual environment initialized in .venv"
fi

# Install dependencies
log_info "Installing Python dependencies..."
.venv/bin/pip install --upgrade pip >/dev/null 2>&1
if [[ -f backend/pyproject.toml ]]; then
  .venv/bin/pip install -e backend >/dev/null 2>&1 || true
fi

# Provision Default CC0 Voice Samples
log_info "Provisioning default voice samples..."
.venv/bin/python backend/scripts/bootstrap/ensure_default_voice_sample.py >/dev/null 2>&1 || true
log_success "Voice samples provisioned"

# ── Create Global `friend` CLI Symlink ────────────────────────────────────────
log_info "Installing global 'friend' CLI command..."

BIN_DIR="${HOME}/.local/bin"
mkdir -p "$BIN_DIR"

cat << 'EOF' > "${BIN_DIR}/friend"
#!/bin/bash
REPO_ROOT="$(cd "$(dirname "$(readlink -f "${BASH_SOURCE[0]}" 2>/dev/null || realpath "${BASH_SOURCE[0]}" 2>/dev/null || echo "$0")")/.." && pwd)"
# If running through ~/.local/bin wrapper, find real install path:
if [[ -f "${HOME}/AI_friend/start.sh" ]]; then
  REPO_ROOT="${HOME}/AI_friend"
fi

PYTHON_EXEC="${REPO_ROOT}/.venv/bin/python"
if [[ ! -x "$PYTHON_EXEC" ]]; then
  PYTHON_EXEC="python3"
fi

exec "$PYTHON_EXEC" -m scripts.friend_cli "$@"
EOF

chmod +x "${BIN_DIR}/friend"

# Ensure ~/.local/bin is in PATH in shell rc files
SHELL_NAME="$(basename "${SHELL:-bash}")"
RC_FILE="${HOME}/.bashrc"
[[ "$SHELL_NAME" == "zsh" ]] && RC_FILE="${HOME}/.zshrc"

if [[ ":$PATH:" != *":${BIN_DIR}:"* ]]; then
  if [[ -f "$RC_FILE" ]] && ! grep -q '.local/bin' "$RC_FILE" 2>/dev/null; then
    echo -e '\nexport PATH="$HOME/.local/bin:$PATH"' >> "$RC_FILE"
  fi
  export PATH="${BIN_DIR}:$PATH"
fi
log_success "Installed 'friend' command to ${BIN_DIR}/friend"

# ── Summary & Next Steps ─────────────────────────────────────────────────────
echo ""
echo -e "${GREEN}═════════════════════════════════════════════════════════════════${NC}"
echo -e "${BOLD}${GREEN}             AI FRIEND INSTALLATION COMPLETE!                    ${NC}"
echo -e "${GREEN}═════════════════════════════════════════════════════════════════${NC}"
echo -e "Location:  ${BOLD}${TARGET_DIR}${NC}"
echo -e "Commands:"
echo -e "  ${CYAN}friend start${NC}            Start the 9-agent cognitive mesh"
echo -e "  ${CYAN}friend talk${NC}             Open terminal conversation REPL"
echo -e "  ${CYAN}friend persona${NC}          Author your friend's personality"
echo -e "  ${CYAN}friend voice${NC}            Enroll an 8-second custom voice"
echo -e "  ${CYAN}friend status${NC}           Inspect live agent health & RAM"
echo -e "  ${CYAN}friend stop${NC}             Shut down all mesh services"
echo -e "${GREEN}─────────────────────────────────────────────────────────────────${NC}\n"

if [[ "$AUTO_START" == true ]]; then
  read -r -p "Would you like to start AI Friend right now? [Y/n] " RESPONSE || RESPONSE="y"
  RESPONSE="${RESPONSE,,}" # lowercase
  if [[ "$RESPONSE" =~ ^(yes|y|)$ ]]; then
    exec "${TARGET_DIR}/start.sh"
  fi
fi
